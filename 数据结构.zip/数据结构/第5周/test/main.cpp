#include<iostream>
#define MAXLEN 1000
using namespace std;
typedef struct
{
	char ch[MAXLEN];
	int len;
}SString;
void Enter(SString *S)
{
	char c;
	int i;
	S->len=0;
	for(i=0;i<1000;i++)
	{
		cin>>c;
		if(c!='!')
		{
			S->ch [i]=c;
			S->len ++;
		}
		else
		    break;
	}
}
void StrCompare(SString *s)
{
	int i=0;
	int count=1;
	int l=0;
	int m=0;
	for(i=0;i<s->len ;i++ )
	{
		if(s->ch [i]==s->ch [i+1])
		{
			count++;
		}
		else
		{
			if(count>l)
			{
				l=count;
				m=i-count+1;
			}
			count=1;
		}
	}
	if(l>1)
	{
		char c=s->ch [m];
	    for(int n=0;n<l;n++)
	    {
	    	cout<<c;
	    }
    }
    else
    {
    	cout<<"no";
	}
}
int main()
{
	SString *S=new SString;
	Enter(S);
	StrCompare(S);
}
