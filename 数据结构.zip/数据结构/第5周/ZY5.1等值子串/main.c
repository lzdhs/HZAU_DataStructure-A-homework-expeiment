#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    char ch[10000];
    int len;
}string;

void scan(string *s)
{
    char n='0';
    while(1)
    {
        scanf("%c",&n);
        if(n=='!')break;
        s->len++;
        s->ch[s->len]=n;
    }
    s->len++;
    s->ch[s->len]='@';
}

void init(string *s)
{
    s->len=0;
}

int main()
{
    string s;
    init(&s);
    scan(&s);
    string str[100];
    int i=0,j=0,k,max=0,maxpos;//i ch   j di j ge zichuan
    init(&str[0]);

    while(i<s.len)
    {
        str[j].ch[str[j].len]=s.ch[i];
        str[j].len++;
        if(s.ch[i]!=s.ch[i+1])
        {
            str[j].len--;
            //printf("j=%d len=%d\n",j,str[j].len);
            j++;
            init(&str[j]);
        }
        i++;
    }

    for(k=0;k<j;k++)
    {
        if(str[k].len>max)
        {
            max=str[k].len;
            maxpos=k;
        }

    }
if(max!=0)
{
    for(k=0;k<=str[maxpos].len;k++)
    {
        printf("%c",(str[maxpos]).ch[k]);
    }
}
else
{
    printf("no");
}
    return 0;
}
