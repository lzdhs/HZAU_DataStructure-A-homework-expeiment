#include <stdio.h>
#include <stdlib.h>
#define MAX 100

typedef struct
{
    int ch[MAX];
    int top;
}stack;

void push(stack *a,char data)
{
    a->top++;
    a->ch[a->top]=data;
}

int pop(stack *a)
{
    int i=a->ch[a->top];
    a->top--;
    return i;
}

int main()
{
    stack number;
    number.top=-1;
    int num,a;
    char ch;
    scanf("%d",&num);
    while(num)
    {
        a=num%26;
        if(!a)
        {
            num--;
        }
        push(&number,a);
        num/=26;
    }
    while(number.top!=-1)
    {
        ch=pop(&number)+64;
        if(ch==64)ch+=26;
        printf("%c",ch);
    }
    return 0;
}
