#include<bits/stdc++.h>
#include <iostream>
#define MAX 1000

using namespace std;

int result[MAX];
struct link
{
    int maxsize;
    int num[5];
    link* next;
};

link* init(link *p,char s[])
{
    link* head=p;
    int i;
    for(i=0;s[i]!='\0';i++)
    {
        if(i!=0&&i%5==0)
        {
            p->next=new link();
            p=p->next;
        }
        p->num[i%5]=s[i]-'0';
        p->maxsize=i%5;
    }
    p->next=NULL;
    return head;
}

void cal(link* p1,link *p2)
{
    link* p=p1,*q=p2;
    int i=0,j,max_current=0,m=0,n=0;
    for(p=p1;p!=NULL;p=p->next)
    {
        if(p!=p1)
        {
            n+=5;
        }
        for(i=0;i<=p->maxsize;i++)
        {
            for(q=p2;q!=NULL;q=q->next)
            {
                if(q!=p2)
                {
                    m+=5;
                }
                for(j=0;j<=q->maxsize;j++)
                {
                    result[m+n+i+j+1]+=q->num[j]*p->num[i];
                    max_current=max_current>m+n+i+j+1?max_current:m+n+i+j+1;
                }
                //q=q->next;
            }
            m=0;
        }
        //p=p->next;
    }

    int k=0;
    for(k=max_current;k>0;k--)
    {
        if(result[k]>=10)
        {
            result[k-1]+=result[k]/10;
            result[k]%=10;
        }
    }
    if(result[k]==0)
    {
        k++;
    }
    for(;k<=max_current;k++)
    {
        cout<<result[k];
    }
    cout<<endl;
}
int main()
{
    char num1[100],num2[100];
    cin>>num1>>num2;
    link* head1,*head2,*p;
    p=new link();
    head1=init(p,num1);
    p=new link();
    head2=init(p,num2);
    cal(head1,head2);
    return 0;
}

