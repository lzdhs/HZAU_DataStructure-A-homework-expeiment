#include <stdio.h>
#include <stdlib.h>
#define MAX 1000

typedef struct
{
    char ch[MAX];
    int len;
}String;

void del(String *s,int l)
{
    if(!l)return;
    //printf("%d\n",l);
    int i;
    for(i=l+1;i<=s->len;i++)
    {
        s->ch[i-l]=s->ch[i];
    }
    s->len-=l;
    //for(i=1;i<=s->len;i++)
        //printf("%c",s->ch[i]);
}
/*
void BFmatch(String s1,String s2)
{
    int i=1,j=1,start=1;
    while(i<=s1.len&&j<=s2.len)
    {
        if(s1.ch[i]=='*')
        {
            i++;
            continue;
        }
        if(s1.ch[i]==s2.ch[j]||s1.ch[i]=='?')
        {
            i++;j++;
        }
        else
        {
            j++;
        }
    }
    if(j==s2.len-1&&i!=s1.len)
    {
        printf("no");
    }
    else
    {
        printf("yes");
    }
}
*/
void BFmatch(String s1,String s2)
{
    int i=1,j=1;

    while(i<=s1.len&&j<=s2.len)
    {
        if(s1.ch[i]==s2.ch[j]||s1.ch[i]=='?')
        {
            //printf("%d s1 %c\n%d s2 %c\n",i,s1.ch[i],j,s2.ch[j]);
            i++;j++;
        }
        else if(s1.ch[i]=='*'&&s1.ch[i+1]=='*')
        {
            del(&s1,i+1);
            del(&s2,j-1);
            BFmatch(s1,s2);
            return;
        }
        else if(s1.ch[i]=='*')
        {
            //printf("%d s1 %c\n%d s2 %c\n",i,s1.ch[i],j,s2.ch[j]);
            del(&s1,i);
            del(&s2,j-1);
            BFmatch(s1,s2);
            return;
        }
        else
        {
            if(s1.ch[i]=='#')
            {
                printf("no");
                return;
            }
            j++;
        }
    }
    if(s1.ch[i-1]=='#'&&'#'==s2.ch[j-1])
        printf("yes");
    else
        printf("no");
}

void init(String *s)
{
    s->len=0;
}

void scan(String *s)
{
    char n='0';
    while(1)
    {
        n=getchar();
        s->len++;
        s->ch[s->len]=n;
        if(n=='#')break;
    }
    //printf("%d\n",s->len);
}

int main()
{
    String a,b;
    init(&a);init(&b);
    scan(&a);
    getchar();
    scan(&b);
    BFmatch(a,b);
    return 0;
}
