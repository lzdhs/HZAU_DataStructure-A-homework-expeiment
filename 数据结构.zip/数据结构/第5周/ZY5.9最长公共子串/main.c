#include <stdio.h>
#include <stdlib.h>
#define MAX 100

typedef struct
{
    char ch[MAX];
    int len;
}String;

String str[100];
void scan(String *s)
{
    char n='0';
    while(1)
    {
        n=getchar();
        if(n==32||n==10)break;
        s->len++;
        s->ch[s->len]=n;
    }
}

void init(String *s)
{
    s->len=0;
}

int search(String s,int pos,char n)
{
    int i;
    for(i=pos;i<=s.len;i++)
    {
        if(s.ch[i]==n)
            return 1;
    }
    return 0;
}

int BFmatch(String s1,String s2,int begin,int end)
{
    int i=1,j=begin,start=1,k;

    while(i<=s1.len&&j<=end)
    {
        if(s1.ch[i]==s2.ch[j])
        {
            i++;j++;
        }
        else{
            start++;
            i=start;j=begin;
        }
        if(j>end)
        {
            for(k=begin;k<=end;k++)
            {
                printf("%c",s2.ch[k]);
            }
            return 1;
        }
    }
    return 0;
}

int main()
{
    String a,b;
    int num,i;
    init(&a);
    init(&b);
    scan(&a);
    scan(&b);
    if(a.len>b.len)
    {
        num=b.len;
        while(num)
        {
            for(i=1;i+num-1<=b.len;i++)
            {
                if(BFmatch(a,b,i,i+num-1))
                    return 0;
            }
            num--;
        }

    }
    else
    {
        num=a.len;
        while(num)
        {
            for(i=1;i+num-1<=num;i++)
            {
                if(BFmatch(b,a,i,i+num-1))
                    return 0;
            }
            num--;
        }
    }
    return 0;
}
//abcdefaabcd
//abcdjfkssabcd
