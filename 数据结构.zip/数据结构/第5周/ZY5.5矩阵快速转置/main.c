#include <stdio.h>
#include <stdlib.h>
#define MAX 10000

typedef struct
{
    int row;
    int col;
    int value;
}elem;

typedef struct
{
    elem data[MAX];
    int m,n,none0cnt;
}juzhen;

void transpose(juzhen a,juzhen *b)
{
    int col,i,j,k;
    int num[MAX],pos[MAX];
    b->none0cnt=a.none0cnt;
    b->m=a.n;
    b->n=a.m;

    if(b->none0cnt)
    {
        for(col=1;col<=a.n;col++)
            num[col]=0;

        for(i=1;i<=a.none0cnt;i++)
            num[a.data[i].col]++;

        pos[1]=1;

        for(col=2;col<=a.n;col++)
            pos[col]=pos[col-1]+num[col-1];

        for(j=1;j<=a.none0cnt;j++)
        {
            col=a.data[j].col;
            k=pos[col];
            b->data[k].row=a.data[j].col;
            b->data[k].col=a.data[j].row;
            b->data[k].value=a.data[j].value;
            pos[col]++;
        }
    }
}

int main()
{
    int m,n,i,j,k,num,flag=0;
    juzhen a,b;
    scanf("%d %d",&m,&n);
    a.m=m;a.n=n;
    a.none0cnt=0;
    for(i=1;i<=m;i++)
    {
        for(j=1;j<=n;j++)
        {
            scanf("%d",&num);
            if(num)
            {
                a.none0cnt++;
                a.data[a.none0cnt].row=i;
                a.data[a.none0cnt].col=j;
                a.data[a.none0cnt].value=num;
            }
        }
    }
    transpose(a,&b);

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++)
        {
            flag=0;
            for(k=1;k<=b.none0cnt;k++)
            {
                if(b.data[k].row==i&&b.data[k].col==j)
                {
                    flag=1;
                    printf("%d ",b.data[k].value);
                    break;
                }
            }
            if(!flag)
            {
                printf("0 ");
            }
        }
        printf("\n");
    }
    return 0;
}
