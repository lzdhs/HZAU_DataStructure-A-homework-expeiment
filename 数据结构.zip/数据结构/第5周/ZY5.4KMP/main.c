#include <stdio.h>
#include <stdlib.h>
#define MAX 100
int next[MAX];
typedef struct
{
    char ch[MAX];
    int len;
}String;

void scan(String *s)
{
    char n='0';
    while(1)
    {
        scanf("%c",&n);
        if(n==32||n==10)break;
        s->len++;
        s->ch[s->len]=n;
    }
}

void init(String *s)
{
    s->len=0;
}

int KMPmatch(String s1,String s2)
{
    int i=1,j=1;
    while(i<=s1.len&&j<=s2.len)
    {
        if(j==0||s1.ch[i]==s2.ch[j])
        {
            i++;j++;
        }
        else
        {
            j=next[j];
        }
    }
    if (j==s2.len+1)return i-s2.len;
    else return 0;
}

void getnext(String s)
{
    next[0]=0;
    int i=1,j=0;
    while(i<=s.len)
    {
        if(j==0||s.ch[i]==s.ch[j])
        {
            i++;j++;
            next[i]=j;
        }
        else{j=next[j];}
    }
}

int main()
{
    String s1,s2;
    init(&s1);
    init(&s2);
    scan(&s1);
    scan(&s2);
    getnext(s2);
    printf("%d\n",KMPmatch(s1,s2));
    init(&s1);
    init(&s2);
    scan(&s1);
    scan(&s2);
    getnext(s2);
    printf("%d\n",KMPmatch(s1,s2));
    init(&s1);
    init(&s2);
    scan(&s1);
    scan(&s2);
    getnext(s2);
    printf("%d\n",KMPmatch(s1,s2));
    return 0;
}
