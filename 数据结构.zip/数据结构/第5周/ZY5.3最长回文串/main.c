#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    char ch[10000];
    int len;
}string;

void init(string *s)
{
    s->len=0;
}

void scan(string *s)
{
    char n='0';
    while(1)
    {
        scanf("%c",&n);
        if(n==10||n==32)break;
        s->len++;
        s->ch[s->len]=n;
    }
}


int huiwen(string *s,int pos)
{
    int i=1,l;
    if(pos==1)return 1;
    while(pos-i>=1&&pos+i<=s->len)
    {
        if(s->ch[pos-i]!=s->ch[pos+i])
        {
            if(i==1)break;
            else
            {
                l=2*i-1;//babad
                break;
            }
        }
        i++;
    }
    //printf("pos=%d,i=%d\n",pos,i);
    if(pos-i==0){l=2*i-1;}
    if(pos+i==s->len+1)l= 2*i-1;
    i=0;
    while(pos-i>=1&&pos+i<=s->len)
    {
        if(s->ch[pos-i]!=s->ch[pos+i+1])
        {
            if(2*i>l) return 2*i;
            else return l;
        }
        i++;
    }
    if(2*i>l) return 2*i;
    else return l;
}

void wnx(string *s)
{
    int i,max=0,a,maxpos=1;
    for(i=1;i<s->len;i++)
    {
        a=huiwen(s,i);
        //printf("%d\n",a);
        if(max<a)
        {
            max=a;
            maxpos=i;
        }
    }
    if(max%2)
    {
        for(i=maxpos-max/2;i<=maxpos+max/2;i++)
        {
            printf("%c",s->ch[i]);
        }
    }
    else
    {
        for(i=maxpos-max/2+1;i<=maxpos+max/2;i++)
        {
            printf("%c",s->ch[i]);
        }
    }
}
int main()
{
    string a;
    init(&a);
    scan(&a);
    wnx(&a);
    return 0;
}



