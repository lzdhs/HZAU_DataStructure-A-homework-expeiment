#include <iostream>

using namespace std;

typedef struct
{
    int ver[100];
    int graph[100][100];
    int vexnum,arcnum;
}Graph;

typedef struct
{
    int adjvex;
    int low;
}shortedge;

int all=0;

void creategraph(Graph &g)
{
    int i,j;
    scanf("%d %d",&g.vexnum,&g.arcnum);
    for(i=1;i<=g.vexnum;i++)
    {
        g.ver[i]=i;
        for(j=1;j<=g.vexnum;j++)
        {
            g.graph[i][j]=(i==j)?0:32767;
        }
    }

    int num1,num2,weigh;
    for(i=1;i<=g.arcnum;i++)
    {
        scanf("%d %d %d",&num1,&num2,&weigh);
        g.graph[num1][num2]=weigh;
        g.graph[num2][num1]=weigh;
    }
}

int mini(Graph &g,shortedge *s)
{
    int i,min,loc=-1;
    min=32767;
    for(i=1;i<=g.vexnum;i++)
    {
        if(min>s[i].low && s[i].low!=0)
        {
            min=s[i].low;
            loc=i;
        }
    }
    return loc;
}

void prim(Graph &g,int n)
{
    int i,j,k;
    shortedge s[100];
    s[1].low=0;

    for(i=2;i<=g.vexnum;i++)
    {
        s[i].adjvex=n;
        s[i].low=g.graph[n][i];
    }
    //cout<<"1";
    for(k=1;k<g.vexnum;k++)
    {
        j=mini(g,s);
        all+=s[j].low;
        //printf(" %d",j);
        s[j].low=0;
        for(i=1;i<=g.vexnum;i++)
        {
            if(g.graph[j][i]<s[i].low)
            {
                s[i].low=g.graph[j][i];
                s[i].adjvex=j;
            }
        }
    }
}

int main()
{
    Graph g;
    creategraph(g);
    prim(g,1);
    cout<<all;
    return 0;
}
