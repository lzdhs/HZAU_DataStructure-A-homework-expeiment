#include <iostream>

using namespace std;

void insort(int r[],int n)
{
    int i,j;
    for(i=2;i<=n;i++)
    {
        r[0]=r[i];
        j=i-1;
        while(r[0]>r[j])
        {
            r[j+1]=r[j];
            j--;
        }
        r[j+1]=r[0];
    }
}

int main()
{
    int num,i=1,a[50];
    while(1)
    {
        cin>>num;
        if(!num)
            break;
        a[i++]=num;
    }
    insort(a,i-1);
    for(num=1;num<i;num++)
        cout<<a[num]<<" ";
    return 0;
}
