#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <string.h>
#define N 1000000
#define HN 1000003
using namespace std;

int head[HN],next_[N];
int bef[N][9],goal[9];
int dis[N];
int dirx[]={-1,1,0,0},diry[]={0,0,-1,1};

int Hash(int bef[])
{
    int v=0,i;
    for(i=0;i<9;++i)
        v=v*10+bef[i];
    return v%HN;
}

int try_insert(int rear)
{
    int h=Hash(bef[rear]);
    int u=head[h];
    while(u)
    {
        if(!memcmp(bef[u],bef[rear],sizeof(bef[0])))
            return 0;
        u=next_[u];
    }
    next_[rear] = head[h];
    head[h] = rear;
    return 1;
}

int bfs()
{
    memset(head,0,sizeof(head));
    int fron=1,rear=2,i,j;
    while(fron<rear)
    {
        if(!memcmp(goal,bef[fron],sizeof(bef[0])))
            return fron;
        for(i=0;i<9;i++)
            if(!bef[fron][i])
                break;

        int x=i/3,y=i%3;
        for(j=0;j<4;j++)
        {
            int nx=x+dirx[j],ny=y+diry[j];
            int nz=3*nx+ny;

            if(nx>=0 && nx<3 && ny>=0 && ny<3)
            {
                memcpy(&bef[rear],&bef[fron],sizeof(bef[0]));
                bef[rear][nz]=bef[fron][i];
                bef[rear][i]=bef[fron][nz];
                dis[rear]=dis[fron]+1;
                if(try_insert(rear))
                    rear++;
            }
        }
        fron++;
    }
    return 0;
}

int main()
{
    int i;
    for(i=0;i<9;i++)
        cin>>bef[1][i];
    for(i=0;i<9;i++)
        cin>>goal[i];
    int ans=bfs();
    cout<<dis[ans];
    return 0;
}
