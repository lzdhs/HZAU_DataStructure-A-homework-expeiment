#include <iostream>

using namespace std;

typedef struct
{
    int arm[6];
}snowflakes;

snowflakes xh[100000];
long long int n;

int equal_(snowflakes a,snowflakes b)
{
    int i,j=0,cnt=0,flag=0;
    for(i=0;i<6;i++)
    {
        if(a.arm[i]==b.arm[j])
        {
            flag=1;
            break;
        }
    }
    int temp=i;
    if(flag)
    {
        while(1)
        {
            if(i==6)
                i=0;
            if(a.arm[i]==b.arm[j])
            {
                i++;j++;cnt++;
            }
            else
                break;
            if(cnt==6)
                return 1;
        }
        i=temp;
        j=0;
        cnt=0;
        while(1)
        {
            if(i==6)
                i=0;
            if(j<0)
                j=5;
            if(a.arm[i]==b.arm[j])
            {
                i++;j--;cnt++;
            }
            else
                return 0;
            if(cnt==6)
                return 1;
        }
    }
    else
    {
        return 0;
    }
    return 0;
}

int check()
{
    long long int i,j;
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(equal_(xh[i],xh[j]))
                return 1;
        }
    }
    return 0;
}

int main()
{
    long long int i;
    int j;
    cin>>n;
    for(i=0;i<n;i++)
    {
        for(j=0;j<6;j++)
        {
            cin>>xh[i].arm[j];
        }
    }
    if(check())
        cout<<"Twin snowflakes found.";
    else
        cout<<"No two snowflakes are alike.";
    return 0;
}
