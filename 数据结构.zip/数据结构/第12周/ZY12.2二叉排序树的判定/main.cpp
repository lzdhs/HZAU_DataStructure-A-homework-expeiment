#include <iostream>
#include <stack>

using namespace std;

typedef struct node
{
    int data;
    node *lchild,*rchild;
}node,*tree;

int cnt1=0,cnt2=0;

/*int findpos(int ch,int s[])
{
    int i=0;
    for(i=0;i<cnt2;i++)
    {
        if(s[i]==ch)
            return i;
    }
    return 0;
}

void generatetree(tree *root,int s1[],int s2[])
{
    *root=new node;
    (*root)->lchild=(*root)->rchild=NULL;
    (*root)->data=s1[0];
    tree temp=*root;
    tree newroot;
    int i=0,rootpos;//in s2
    stack <tree> s;
    s.push(temp);
    s.push(temp);
    rootpos=findpos(s1[0],s2);
    while(i<cnt1)
    {
        i++;
        if(findpos(s1[i],s2)<rootpos)
        {
            newroot=new node;
            newroot->lchild=newroot->rchild=NULL;
            temp->lchild=newroot;
            newroot->data=s1[i];
            temp=newroot;
            rootpos=findpos(s1[i],s2);
            s.push(temp);
        }
        else
        {
            temp=s.top();
            s.pop();
            rootpos=findpos(s1[i],s2);

            if(findpos(s.top()->data,s2)>rootpos)//s.top().lchild==NULL
            {
                newroot=new node;
                newroot->lchild=newroot->rchild=NULL;
                temp->rchild=newroot;
                newroot->data=s1[i];
                temp=newroot;
                s.push(temp);
            }
            else
            {
                temp=s.top();
                s.pop();
                newroot=new node;
                newroot->lchild=newroot->rchild=NULL;
                temp->rchild=newroot;
                newroot->data=s1[i];
                temp=newroot;
                s.push(temp);
            }

        }
    }
}*/

int findpos(int ch, int s[], int cnt) {
    for (int i = 0; i < cnt; i++) {
        if (s[i] == ch) return i;
    }
    return -1;
}

tree build(int s1[], int s2[], int s1Len, int s2Len)
{
    if (s1Len == 0) return NULL;
    if (s1[0] == -1) return NULL;

    int c = s1[0];
    int pos = findpos(c, s2, s2Len);

    tree root = new node;
    root->data=c;
    root->lchild=root->rchild=NULL;
    root->lchild = build(s1 + 1, s2, pos, pos);


    root->rchild = build(s1 + pos + 1, s2 + pos + 1, s1Len - pos - 1, s2Len - pos - 1);

    return root;
}

/*void generatetree(tree *root,int s1[],int s2[])
{
    *root=new node;
    (*root)->lchild=(*root)->rchild=NULL;
    (*root)->data=s1[0];
    tree temp=*root;
    tree newroot;
    int i=0,rootpos;//in s2
    stack <tree> s;
    rootpos=findpos(s1[0],s2);

    while(i<cnt1)
    {
        i++;
        if(findpos(s1[i],s2)<rootpos)
        {
            s.push(temp);
            newroot=new node;
            newroot->lchild=newroot->rchild=NULL;
            temp->lchild=newroot;
            newroot->data=s1[i];
            temp=newroot;
            rootpos=findpos(s1[i],s2);
        }
        else
        {
            temp=s.top();
            s.pop();
            rootpos=findpos(s1[i],s2);

            if(s.empty() || ((findpos(temp->data,s2) < rootpos) && (findpos(s.top()->data,s2) > rootpos)) )
            {
                s.push(temp);
                newroot=new node;
                newroot->lchild=newroot->rchild=NULL;
                newroot->data=s1[i];
                temp->rchild=newroot;
                temp=newroot;
            }

            else if(!s.empty() && (findpos(s.top()->data,s2) < rootpos))
            {
                temp=s.top();
                s.pop();
                i--;
            }

            else if(!s.empty())
            {
                s.push(newroot);
                newroot->lchild=new node;
                newroot=newroot->lchild;
                newroot->lchild=newroot->rchild=NULL;
                newroot->data=s1[i];
            }
        }
    }
}*/

int arr[50],num=0;

void midorder(tree root)
{
    if(root)
    {
        midorder(root->lchild);
        arr[num++]=root->data;
        midorder(root->rchild);
    }
}

int wnx()
{
    int i=0;
    for(i=0;i<num-2;i++)
    {
        //cout<<arr[i]<<" ";
        if(arr[i]>arr[i+1])
            return 0;
    }
    return 1;
}

int main()
{
    int pre[50],mid[50];
    int n;
    while(cin>>n)
    {
        if(n)
            pre[cnt1++]=n;
        else
            break;
    }
    while(cin>>n)
    {
        if(n)
            mid[cnt2++]=n;
        else
            break;
    }
    tree root;
    root=build(pre,mid,cnt1,cnt2);
    midorder(root);
    if(wnx())
        cout<<"true";
    else
        cout<<"false";
    return 0;
}
