#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,k,a[100],i,b[50];
    scanf("%d",&n);
    for(i=0;i<n-1;i++)
    {
        scanf("%d",&a[i]);
        getchar();
    }
    scanf("%d",&a[n-1]);
    scanf("%d",&k);
    int low=0,high=n-1,mid=0;
    int flag=1,j=0;
    while(low<=high && flag)
    {
        mid=(low+high)/2;
        if(k == a[mid])
            flag=0;
        else if(k < a[mid])
            {
                high=mid-1;
                b[j++]=mid;
            }
        else
            {
                low=mid+1;
                b[j++]=mid;
            }
    }
    if(flag)
    {
        printf("no\n");
    }
    else
    {
        printf("%d\n",mid);
    }
    printf("%d",a[b[0]]);
    for(i=1;i<j;i++)
        printf(",%d",a[b[i]]);
    if(!flag)
        printf(",%d",a[mid]);
    return 0;
}
