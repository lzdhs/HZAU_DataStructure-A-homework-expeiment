#include <iostream>

using namespace std;

typedef struct node
{
    int data;
    node *lchild,*rchild;
}node,*tree;

void insertbst(tree *bst,int n)
{
    tree s;
    if(*bst==NULL)
    {
        s=new node;
        s->data=n;
        s->lchild=s->rchild=NULL;
        *bst=s;
    }
    else if(n < (*bst)->data)
        insertbst(&((*bst)->lchild),n);
    else if(n > (*bst)->data)
        insertbst(&((*bst)->rchild),n);
}

void createbst(tree *bst)
{
    int data;
    *bst=NULL;
    cin>>data;
    while(data)
    {
        insertbst(bst,data);
        cin>>data;
    }
}

void pre(tree root)
{
    if(root)
    {
        cout<<root->data<<" ";
        pre(root->lchild);
        pre(root->rchild);
    }
    else
        cout<<"# ";
}

node* del(tree &t,int k)
{
    node *p,*f,*s,*q;
    p=t;
    f=NULL;
    while(p)
    {
        if(p->data == k)
            break;
        f=p;
        if(p->data > k)
            p=p->lchild;
        else
            p=p->rchild;
    }
    if(p==NULL) return t;
    if(p->lchild == NULL)
    {
        if(f == NULL)
            t=p->rchild;
        else if(f->lchild==p)
            f->lchild=p->rchild;
        else
            f->rchild=p->rchild;
    }
    else
    {
        q=p;
        s=p->lchild;
        while(s->rchild)
        {
            q=s;
            s=s->rchild;
        }
        if(q==p)
            q->lchild=s->lchild;
        else
            q->rchild=s->lchild;
        p->data=s->data;
    }
    return t;
}

void mid(tree root)
{
    if(root)
    {
        mid(root->lchild);
        cout<<root->data<<" ";
        mid(root->rchild);
    }
}

int findlevel(tree root,int y,int level)
{
    if (!root) return 0;
    if (root->data == y) return level;
    if (y < root->data) return findlevel(root->lchild, y,level+1);
    return findlevel(root->rchild, y,level+1);
}

int main()
{
    int n;
    tree root;
    createbst(&root);
    pre(root);
    cout<<endl;
    int k;
    scanf("%d",&k);
    node *p=del(root,k);
    mid(p);
    cin>>n;
    cout<<endl<<findlevel(root,n,1);
    return 0;
}
