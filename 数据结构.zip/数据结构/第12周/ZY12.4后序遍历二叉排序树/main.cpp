#include <iostream>

using namespace std;

int verify(int *post,int start,int ed)
{
    if(start>=ed)
    {
        return 1;
    }

    int i=start;
    while(i < ed-1 && post[i] < post[ed-1])
    {
        i++;
    }
     int j;
     for(j=i;j<ed-1;j++)
     {
         if(post[j] < post[ed-1])
            return 0;
     }
     return (verify(post,start,i-1) && verify(post,i,ed-1));
}
int main()
{
    int a[50],n,i=0;
    while(cin>>n)
    {
        a[i]=n;
        i++;
    }
    if(verify(a,0,i-1))
        cout<<"true";
    else
        cout<<"false";
    return 0;
}
