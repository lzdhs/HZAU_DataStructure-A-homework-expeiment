#include<iostream>
using namespace std;

long long a[35][35];

void init()
{
    int i,j;
    for(i=0;i<35;i++)
    {
        a[0][i]=1;
    }
    for(i=1;i<35;i++)
    {
        for(j=i;j<=35;j++)
        {
            if(i==j)
            {
                a[i][j] = a[i-1][j];
            }
            else
            {
               a[i][j]=a[i-1][j]+a[i][j-1];
            }
        }
    }
}

int main(){
	int num=0;
	int  input=0;
    init();
	while(1)
    {
        cin>>input;
        if(input==-1)break;
        num++;
		cout<<num<<" "<<input<<" "<<a[input][input]*2<<endl;
	}
	return 0;
}
