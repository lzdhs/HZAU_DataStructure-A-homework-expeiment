#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int data;
    struct node* next;
}node;

typedef struct
{
    node *front;
    node *rear;
}quene;

typedef struct
{
    int arr[10000];
    int top;
}stack;

void initquene(quene *q)
{
    q->front=(node*)malloc(sizeof(node));
    q->rear=q->front;
    q->front->next=NULL;
}

void initstack(stack *s)
{
    s->top=-1;
}

void pushnum(stack *s,int n)
{
    s->top++;
    s->arr[s->top]=n;
}

int popnum(stack *s)
{
    int n;
    n=s->arr[s->top];
    s->top--;
    return n;
}

void enterquene(quene *q,int n)
{
    node *newnode;
    newnode=(node *)malloc(sizeof(node));
    newnode->data=n;
    newnode->next=NULL;
    q->rear->next=newnode;
    q->rear=newnode;
}

int del(quene *q)
{
    node *p;
    p=q->front->next;
    q->front->next=p->next;
    if(q->rear==p)
        q->rear=q->front;
    int n=p->data;
    return n;
}

int main()
{
    quene q;
    quene *pq=&q;
    initquene(pq);
    stack s;
    stack *p=&s;
    initstack(p);
    int count,i,n;
    scanf("%d",&count);
    for(i=0;i<count;i++)
    {
        scanf("%d",&n);
        enterquene(pq,n);
    }
    for(i=0;i<count;i++)
    {
        pushnum(p,del(pq));
    }
    while(p->top!=-1)
    {
        printf("%d ",popnum(p));
    }
    return 0;
}
