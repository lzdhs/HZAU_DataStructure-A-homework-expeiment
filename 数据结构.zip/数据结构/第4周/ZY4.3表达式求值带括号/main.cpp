#include <iostream>

using namespace std;

typedef struct
{
    double num[1000];
    char oper[100];
    int topn;
    int topo;
}sta;

void init(sta *s)
{
    s->topn=-1;
    s->topo=-1;
}

void pushnum(sta *s,double n)
{
    //cout<<"the num you pushed is "<<n<<endl;
    s->topn++;
    s->num[s->topn]=n;
}

void pushoper(sta *s,char n)
{
    //cout<<"the oper you pushed is "<<n<<endl;
    s->topo++;
    s->oper[s->topo]=n;
}

char popoper(sta *s)
{
    char ch;
    ch=s->oper[s->topo];
    s->topo--;
    return ch;
}

double popnum(sta *s)
{
    double n;
    n=s->num[s->topn];
    s->topn--;
    return n;
}

char gettop(sta *s)
{
    char n=s->oper[s->topo];
    //cout<<"n"<<n<<endl;
    return n;
}

char compare(char ch,char t)
{
    //cout<<"compare has called"<<endl;
    char op[7]={'+','-','*','/','(',')','#'};
    char relation[7][7]={{'>','>','<','<','<','>','>'},
    {
        '>','>','<','<','<','>','>'
    },
    {
        '>','>','>','>','<','>','>'
    },
    {
        '>','>','>','>','<','>','>'
    },
    {
        '<','<','<','<','<','=','>'
    },
    {
        ' ',' ',' ',' ',' ',' ',' '
    },
    {
        '<','<','<','<','<',' ','='
    }
    };
    int k,i,j;
    for(k=0;k<7;k++)
    {
        if(op[k]==ch)i=k;
        if(op[k]==t)j=k;
    }
    //cout<<relation[i][j];
    return relation[i][j];
}

double cal(double n1,char op,double n2)
{
    //cout<<"cal has called"<<endl;
    switch(op)
    {
        case '+':return n1+n2;
        case '-':return n2-n1;
        case '*':return n1*n2;
        case '/':return n2/n1;
    }
}

int main()
{
    sta s;
    char ch,chpop;
    double num,num1,num2,aftercal=0;
    sta *top=&s;
    init(top);
    pushoper(top,'#');

    cin>>ch;
    while(ch!='#'||top->topo!=0)
    {
        if(ch>='0'&&ch<='9')
        {
            cin.putback(ch);
            cin>>num;
            //cout<<"NUM"<<num<<endl;
            pushnum(top,num);
            cin>>ch;
        }
        else
        {
            //cout<<"get"<<gettop(top)<<"ch"<<ch<<endl;
            switch(compare(gettop(top),ch))
            {
                case '<':pushoper(top,ch);cin>>ch;break;
                case '=':chpop=popoper(top);cin>>ch;break;
                case '>':chpop=popoper(top);num1=popnum(top);num2=popnum(top);
                /*cout<<"chpop"<<chpop<<"num1"<<num1<<"num2"<<num2<<endl;*/aftercal=cal(num1,chpop,num2);pushnum(top,aftercal);break;
            }
        }
    }
    printf("%.2f",aftercal);
    return 0;
}

