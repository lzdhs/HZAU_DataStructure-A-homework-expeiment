#include <stdio.h>
#include <stdlib.h>

void print(int *p,int n,int index)
{
    int i,j;
    for(i=0;i<index;i++)
        for(j=i+1;j<index;j++)
    {
        if(p[j]>p[i])return;
    }
    for(i=0;i<index;i++)
    {
        printf("%d",p[i]);
        if(i<index-1)
        {
            printf("+");
        }
    }
    printf("\n");
}

void divide(int n,int arr[],int index)
{
    int i;
    if(n==0)
    {
        print(arr,n,index);
        return;
    }
    else
    {
        for(i=n;i>=1;i--)
        {
            arr[index]=i;
            divide(n-i,arr,index+1);
        }
    }
}
int main()
{
    int num;
    scanf("%d",&num);
    int *p=(int *)malloc(num*sizeof(int));
    divide(num,p,0);
    return 0;
}
