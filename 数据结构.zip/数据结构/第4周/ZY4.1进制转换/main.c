#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int str[10000];
    int top;
}stack;

void init(stack *s)
{
    s->top=-1;
}

void push(stack *s,int n)
{
    s->top++;
    s->str[s->top]=n;
}

int pop(stack *s)
{
    int n;
    n=s->str[s->top];
    s->top--;
    return n;
}

int main()
{
    int b,numbef,n,numaft;
    char chaft;
    stack s;
    stack *p=&s;
    init(p);
    scanf("%d",&numbef);
    scanf("%d",&b);
    while(numbef)
    {
        n=numbef%b;
        push(p,n);
        numbef/=b;
    }
    while(p->top!=-1)
    {
        numaft=pop(p);
        switch(numaft)
        {
            case 10:chaft='A';printf("%c",chaft);break;
            case 11:chaft='B';printf("%c",chaft);break;
            case 12:chaft='C';printf("%c",chaft);break;
            case 13:chaft='D';printf("%c",chaft);break;
            case 14:chaft='E';printf("%c",chaft);break;
            case 15:chaft='F';printf("%c",chaft);break;
            default:printf("%d",numaft);
        }
    }
    return 0;
}
