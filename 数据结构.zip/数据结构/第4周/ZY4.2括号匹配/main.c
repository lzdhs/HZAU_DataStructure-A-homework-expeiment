#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    char data;
    struct node *next;
}node,*stack;

void init(stack *s)
{
    *s=(node*)malloc(sizeof(node));
}

void push(stack s,char ch)
{
    node *temp=(node*)malloc(sizeof(node));
    temp->next=s->next;
    temp->data=ch;
    s->next=temp;
}

char pop(stack s)
{
    node *temp;
    temp=s->next;
    char ch=temp->data;
    s->next=temp->next;
    free(temp);
    return ch;
}

int match(char s1,char s2)
{
    if((s1=='('&&s2==')')||(s1=='['&&s2==']')||(s1=='{'&&s2=='}'))
       return 1;
    else
        return 0;
}
int main()
{
    stack s;
    init(&s);
    char str[10000],ch;
    int i;
    scanf("%9999s",str);
    for(i=0;str[i]!='\0';i++)
    {
        switch(str[i])
        {
        case '(':
        case '[':
        case '{':
            push(s,str[i]);break;
        case ')':
        case ']':
        case '}':
            if(s->next==NULL)
            {
                printf("NO");
                return 0;
            }
            else
            {
                ch=pop(s);
                if(match(ch,str[i]))
                {

                }
                else
                {
                    printf("NO");
                    return 0;
                }
            }break;
        }

    }
    if(s->next==NULL)
    {
        printf("YES");
    }
    else
    {
        printf("NO");
    }
    return 0;
}
