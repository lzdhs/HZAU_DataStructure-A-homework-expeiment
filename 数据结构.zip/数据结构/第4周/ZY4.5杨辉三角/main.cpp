#include<stdio.h>
#include<stdlib.h>
#define MAXQSIZE 1000000

typedef struct
{
	int *base;
	int top;
	int rear;
}Queue;

void init(Queue &Q)
{
	Q.base=new int[MAXQSIZE];
	Q.top=Q.rear=0;
}

void enter(Queue &Q,int e)
{
	Q.base[Q.rear]=e;
	Q.rear=(Q.rear+1)%MAXQSIZE;
}

int del(Queue &Q)
{
    int e=Q.base[Q.top];
	Q.top=(Q.top+1)%MAXQSIZE;
    return e;
}

int gethead(Queue &Q)
{
	int e=Q.base[Q.top];
	return e;
}

int IsEmpty(Queue &Q)
{
	if(Q.rear==Q.top)
		return 1;
	else
		return 0;
}

void YHTriangle(int n){
	int i,j,s=0,t=0;
	Queue Q;
	init(Q);
	enter(Q,1);
	enter(Q,1);
	for(i=1;i<n;i++)
    {
		enter(Q,0);
		for(j=1;j<=i+2;j++)
		{
			t=del(Q);
			enter(Q,s+t);
			s=t;
			if(j!=i+2){
				printf("%d ",s);
			}
		}
		printf("\n");
	}
}

int main() {
	int N;
	scanf("%d", &N);
	printf("1\n");
	YHTriangle(N);
	return 0;
}
