#include <stdio.h>
#include <stdlib.h>


char maze[20][20];


typedef struct
{
    int x,y;      // ���кź��к���Ϊ������λ�á�����
}PosType;

typedef struct
{
    int num;       // ͨ������·���ϵ����
    PosType pos; // ͨ�������Թ��еġ�����λ�á�
    int dir;            // �Ӵ�ͨ����������һͨ����ġ����� 1��2��3��4��
}SElemType;           // �����ջԪ�ص�����

typedef struct//define the stack;
{
    SElemType *base;
    SElemType *top;
    int stacksize;
}stack;


void init(stack *s)//stack init func;
{
    s->base=(SElemType*)malloc(10*sizeof(SElemType));
    s->top=s->base;
    s->stacksize=10;
}

int pass(char maze[][20],PosType *s)
{
    //printf("pos=%c?\n",maze[s->x][s->y]);
    if(maze[s->x][s->y]==' '||maze[s->x][s->y]=='E'||maze[s->x][s->y]=='S')
        return 1;
    else
        return 0;
}

void footprint(char maze[][20],PosType *s)
{
    maze[s->x][s->y]='*';
}

void push(stack *s,SElemType *e)
{
    SElemType *newbase;
    if( (s->top-s->base )>= s->stacksize )
    {
        newbase=(SElemType*)realloc(s->base,(s->stacksize+10)*sizeof(SElemType));
        s->base = newbase;
        s->stacksize+=10;
    }
    *(s->top)++=*e;
}

void pop(stack *s,SElemType *e)
{
    *e = *--(s->top);
}

void markprint(char maze[][20],PosType *s)
{
    maze[s->x][s->y]='!';
}

int isempty(stack *s)
{
    if(s->base==s->top)
        return 1;
    return 0;
}

PosType nextpos(PosType *s,int dir)
{
    if(dir==1)
    {
        (s->y)++;
    }
    else if(dir==2)
    {
        (s->x)++;
    }
    else if(dir==3)
    {
        (s->y)--;
    }
    else
    {
        (s->x)--;
    }
    return *s;
}

int findpath(char maze[][20],PosType start,PosType end)
{
    stack s;
    init(&s);
    PosType curpos=start;//curpos:currentpositon
    SElemType e;
    int curstep=1;//curstep:currentstep
    do
    {
        if(pass(maze,&curpos))
        {
            footprint(maze,&curpos);
            e.dir=1;
            e.pos=curpos;
            e.num=curstep;
            push(&s,&e);
            if(curpos.x==end.x&&curpos.y==end.y)
            {
                return 1;
            }
            curpos=nextpos(&curpos,e.dir);
            curstep++;
        }
        else
        {
            if(!isempty(&s))
            {
                pop(&s,&e);
                while(e.dir==4&&!isempty(&s))
                {
                    markprint(maze,&e.pos);
                    pop(&s,&e);
                }
                if(e.dir<4)
                {
                    (e.dir)++;
                    push(&s,&e);
                    curpos=nextpos(&curpos,e.dir);
                }
            }
        }
    }while(!isempty(&s));
}


int main()
{
    int i,j;
    PosType start,end;
    for(i=0;i<10;i++)
    {
        for(j=0;j<10;j++)
        {
            scanf("%c",&maze[i][j]);
            if(maze[i][j]=='S')
            {
                start.x=i;
                start.y=j;
            }
            if(maze[i][j]=='E')
            {
                end.x=i;
                end.y=j;
            }
        }
        getchar();
    }

    if(findpath(maze,start,end))
    {
        for(i=0;i<10;i++)
        {
            for(j=0;j<10;j++)
            {
                printf("%c",maze[i][j]);
            }
            printf("\n");
        }
    }
    return 0;
}
/*
###########S0#000#0##00#000#0##0000##00##0###0000##000#0000##0#000#00##0###0##0###000000E###########
11#S1��1# 3. 1# 1.2#2.1#3.1#1.2#4.2#2.2#1.3#4.2#3.1#4.2#1.1#3.1#2.2#1.3#1.2#1.3#6.E11#
*/
