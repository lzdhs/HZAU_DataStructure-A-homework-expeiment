#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    char str[10000];
    int top;
}stack;

void init(stack *s)
{
    s->top=-1;
}

void push(stack *s,char ch)
{
    s->top++;
    s->str[s->top]=ch;
}

char pop(stack *s)
{
    char ch;
    ch=s->str[s->top];
    s->top--;
    return ch;
}

int main()
{
    stack s;
    int i=0,j=0;
    init(&s);
    char ch[10000],ch2;
    scanf("%s",&ch[i]);
    for(i=0;ch[i]!='&';i++)
    {
        push(&s,ch[i]);
    }
    for(++i;ch[i]!='@';i++)
    {
        ch2=pop(&s);
        if(ch[i]==ch2)
        {
            j++;
        }
        else
        {
            printf("no");
            return 0;
        }
    }
    printf("%d",j);
    return 0;
}
