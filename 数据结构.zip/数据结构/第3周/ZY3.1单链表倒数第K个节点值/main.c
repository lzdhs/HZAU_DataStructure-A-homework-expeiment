#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
}node,*linklist;

void initlist(linklist *a)
{
    *a=(node*)malloc(sizeof(node));
    (*a)->next=NULL;
}

void createfromtail(linklist a)
{
    int n=1;
    node *r,*s;
    r=a;
    while(1)
    {
        scanf("%d",&n);
        if(n==0)break;
        s=(node *)malloc(sizeof(node));
        s->data=n;
        r->next=s;
        r=s;
    }
    r->next=NULL;
}

int length(linklist a)
{
    int i=1;
    node *p=a->next;
    while(p->next!=NULL)
    {
        i++;
        p=p->next;
    }
    return i;
}

void showlist(linklist L,int i)
{
    node *current=L->next;
    int k;
    //printf("%d,%d",p,i);
    if(i<0){printf("Not Found");return;}
    for(k=1;k<i+1;k++)current=current->next;
    printf("%d",current->data);
}

int main()
{
    int n,num;
    scanf("%d",&n);
    linklist a;
    initlist(&a);
    createfromtail(a);
    num=length(a)-n;
    showlist(a,num);
    return 0;
}
