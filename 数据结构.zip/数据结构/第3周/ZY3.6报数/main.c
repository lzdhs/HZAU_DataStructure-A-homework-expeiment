#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int data;//baoshucishu
    struct node *next;
}node,*linklist;

void initlist(linklist *a)
{
    *a=(node*)malloc(sizeof(node));
    (*a)->next=NULL;
}

void show(linklist a)//to print the linklist
{
    node *p=a;
    do
    {
        printf("%d ",p->data);
        p=p->next;
    }while(p!=a);
}

void createfromtail(linklist a,int num)//Create a looped linked list without a header node
{
    node *r,*s;
    r=a;
    r->data=0;
    while(num-1)
    {
        s=(node *)malloc(sizeof(node));
        s->data=0;
        r->next=s;
        r=s;
        num--;
    }
    r->next=a;
}

int main()
{
    int n,i=0,count=0;//counts,num
    scanf("%d",&n);
    linklist a;
    initlist(&a);
    createfromtail(a,4);
    //show(a);
    node *p=a;
    while(count<=n)
    {
        i++;
        count++;
        if((i%7==0)||(i%10==7)||(i/10==7))
        {
            p->data++;
            count--;
        }
        p=p->next;
    }
    p=a;
    for(i=1;i<=4;i++)
    {
        printf("%d\n",p->data);
        p=p->next;
    }
    return 0;
}
