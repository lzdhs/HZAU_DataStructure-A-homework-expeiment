#include <iostream>

using namespace std;

typedef struct node
{
    int data;
    int num;
    struct node *next;
}node,*linklist;

int length(linklist a)//bianli,changdu
{
    int i=1;
    node *p=a->next;
    while(p->next!=NULL)
    {
        i++;
        p=p->next;
    }
    return i;
}

int createfromtail(linklist a)
{
    int n=1,i=0;
    node *r,*s;
    r=a;
    while(1)
    {
        scanf("%d",&n);
        if(n==0)break;
        i++;
        s=(node *)malloc(sizeof(node));
        s->data=n;
        s->num=i;
        r->next=s;
        r=s;
    }
    r->next=NULL;
    return i;
}

void initlist(linklist *a)
{
    *a=(node*)malloc(sizeof(node));
    (*a)->next=NULL;
}

node* findnode(linklist a,int i)
{
    node* p=a->next;
    while(1)
    {
        if(p->num==i)break;
        p=p->next;
    }
    return p;
}

void swapandshow(linklist a,int n)
{
    node *p=a->next,*temp;int b;
    if(n%2==0)
        b=n/2+1;
    else
        b=(n/2)+2;
    while(n>=b)
    {
        //cout<<n<<endl;
        temp=p->next;
        //cout<<"temp"<<temp->num<<endl;
        p->next=findnode(a,n);
        //if(p->next->num==temp->num)break;
        //cout<<"dade"<<p->next->num<<endl;
        p=p->next;
        p->next=temp;
        p=p->next;
        n--;
    }
    p->next=NULL;
    p=a->next;
    while(p!=NULL)
    {
        cout<<p->data<<" ";
        p=p->next;
    }
}
int main()
{
    int nodecount;
    linklist a;
    initlist(&a);
    nodecount=createfromtail(a);
    swapandshow(a,nodecount);
    return 0;
}
