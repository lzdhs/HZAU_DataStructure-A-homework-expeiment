#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
    struct node *prior;
}node,*linklist;

int length(linklist a)
{
    int i=1;
    node *p=a;
    while(p->next!=NULL)
    {
        i++;
        p=p->next;
    }
    return i;
}

void createfromtail(linklist a)
{
    int n=1;
    node *r,*s;
    r=a;
    scanf("%d",&r->data);
    while(n!=0)
    {
        scanf("%d",&n);
        if(n==0)break;
        s=(node *)malloc(sizeof(node));
        s->data=n;
        s->prior=NULL;
        r->next=s;
        r=s;
    }
    r->next=NULL;
    r=a->next;
    while(r->next!=NULL)
    {
        r->next->prior=r;
        r=r->next;
    }
}

void initlist(linklist *a)
{
    *a=(node*)malloc(sizeof(node));
    (*a)->next=NULL;
    (*a)->prior=NULL;
}

void sort(linklist *l)
{
    int temp,i;
    node *current=*l,*nextnode;
    for(i=1;i<length(*l);i++)
    {
        nextnode=current;
        do
        {
            nextnode=nextnode->next;
            if(nextnode->data<current->data)
            {
                temp=current->data;
                current->data=nextnode->data;
                nextnode->data=temp;
            }
        }while(nextnode->next!=NULL);
        current=current->next;
    }
}

int main()
{
    linklist a;
    initlist(&a);
    createfromtail(a);
    sort(&a);
    node *p=a;
    while(1)
    {
        p=p->next;
        if(p->next==NULL)
        {
            p->next=a;
            a->prior=p;
            break;
        }
    }
    p=a;
    node* temp=p;
    do
    {
        printf("%d ",p->data);
        p=p->next;
    }while(p!=temp);
    return 0;
}
