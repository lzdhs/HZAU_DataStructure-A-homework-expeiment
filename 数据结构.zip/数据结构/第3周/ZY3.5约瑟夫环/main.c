#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
}node,*linklist;

void initlist(linklist *a)
{
    *a=(node*)malloc(sizeof(node));
    (*a)->next=NULL;
}

void show(linklist a)//to print the linklist
{
    node *p=a;
    while(p!=a)
    {
        printf("%d ",p->data);
    }
}

void createfromtail(linklist a,int num)//Create a looped linked list without a header node
{
    int n=1;
    node *r,*s;
    r=a;
    r->data=n;
    while(num-1)
    {
        n++;
        s=(node *)malloc(sizeof(node));
        s->data=n;
        r->next=s;
        r=s;
        num--;
    }
    r->next=a;
}

void kill(linklist a,int n,int peonum)//n=�ڼ����˳�ȥ��peonum��������,i
{
    node *p=a,*q=a->next;
    int i=1;
    if(n!=1)
    {
        while(peonum!=1)
        {
        i++;
        if(i==n)
        {
            //free(p->next);
            p->next=q->next;
            peonum--;
            i=1;
        }
        p=p->next;
        q=p->next;
        }
        printf("\n%d",p->data);
    }
    else
    {
        while(p->next!=a)
        {
            p=p->next;
        }
        printf("%d",p->data);
    }
}

int main()
{
    linklist a;
    int peonum,pos;
    initlist(&a);
    scanf("%d",&peonum);
    createfromtail(a,peonum);
    scanf("%d",&pos);
    kill(a,pos,peonum);
    return 0;
}
