#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int num[100];
    char oper[100];
    int topn;
    int topo;
}stack;

void init(stack *s)
{
    s->topo=s->topn=-1;
}

void pushnum(stack *s,int n)
{
    s->topn++;
    s->num[topn]=n;
}

void pushoper(stack *s,char n)
{
    s->topo++;
    s->oper[topo]=n;
}

int popnum(stack *s)
{
    int i=s->num[s->topn];
    return i;
}

char popnum(stack *s)
{
    char i=s->oper[s->topo];
    return i;
}

char gettop(stack *s)
{
    char i=s->oper[s->topo];
    return i;
}

int compare(char ch,char s)
{
    if(ch=='+'||ch=='-')
    {
        switch(s)
        {
            case '+':case '-':return 1;
            default:return 0;
        }
    }
    else if(ch=='*'||ch=='/')
    {
        return 0;
    }
}

int main()
{
    stack cal;
    int i;
    init(&cal);
    pushoper(&cal,'#');
    char ch='1',chcom;
    while(ch!='='||)
    {
        ch=getchar();
        if(ch=='=')break;
        switch(ch)
        {
            case '0':pushnum(&cal,0);break;
            case '1':pushnum(&cal,1);break;
            case '2':pushnum(&cal,2);break;
            case '3':pushnum(&cal,3);break;
            case '4':pushnum(&cal,4);break;
            case '5':pushnum(&cal,5);break;
            case '6':pushnum(&cal,6);break;
            case '7':pushnum(&cal,7);break;
            case '8':pushnum(&cal,8);break;
            case '9':pushnum(&cal,9);break;
            default:
                {//1+2*3=
                    chcom=gettop(&cal);
                    i=compare(ch,chcom);
                    if(i)
                    {
                        pushoper(&cal,ch);
                    }
                    else
                    {

                    }
                }
        }

    }
    return 0;
}
