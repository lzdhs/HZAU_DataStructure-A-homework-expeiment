#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct
{
	char data;
	int weight;
	int parent;
	int lchild;
	int rchild;
}node;

typedef struct HuffTreeNode
{
	int n;
	int root;
	node* ht;
}treenode,*tree;

typedef struct
{
    int data;
    char s[10];
}ch;

ch c[10];

tree createtree(int n,int w[])
{
	tree pht;
	int i=0,j=0;
	int x1,x2,min1,min2;
	pht=(tree)malloc(sizeof(treenode));
	pht->ht=(node*)malloc(sizeof(node)*(2*n-1));

	for (i=0;i<2*n-1;i++)
	{
		pht->ht[i].lchild=-1;
		pht->ht[i].rchild=-1;
		pht->ht[i].parent=-1;
		if(i<n)
		{
			pht->ht[i].weight=w[i];
			pht->ht[i].data=j+97+'0';
		}
		else
		{
			pht->ht[i].weight=-1;
		}
		j++;
	}

	for (i=0;i<n-1;i++)
	{
		min1=10000;
		min2=10000;
		x1=-1;
		x2=-1;
		for (j=0;j<n+i;j++)
		{
			if (pht->ht[j].weight<min1&&pht->ht[j].parent==-1 )
			{
				min2=min1;
				x2=x1;
				min1=pht->ht[j].weight;
				x1=j;
			}

			else if(pht->ht[j].weight<min2&&pht->ht[j].parent==-1 )
			{
				min2=pht->ht[j].weight;
				x2=j;
			}
		}
		pht->ht[n+i].weight=min1+min2;
		pht->ht[n+i].lchild=x1;
		pht->ht[n+i].rchild=x2;
		pht->ht[x1].parent=n+i;
		pht->ht[x2].parent=n+i;
	}
	pht->root=2*n-2;
	pht->n=n;
	return pht;
}

void print(int n,tree pht)
{
	int i=0,num=0,j=0,k,t;
	int parent=0;
	int times=0;
	int code[10];
	for (i=0;i<n;i++)
	{
		num=i;
		j=0;
		times=0;
		while(pht->ht[num].parent!=-1)
		{
			parent=pht->ht[num].parent;
			if(pht->ht[parent].lchild==num)
			{
				code[j]=0;
				j++;
				times++;
			}
			else if (pht->ht[parent].rchild == num)
			{
				code[j]=1;
				j++;
				times++;
			}
			num=parent;
		}
		k=0;
		for (j=times-1;j>=0;j--)
		{
			printf("%d",code[j]);
			c[i].s[k++]=code[j]+'0';
		}
		printf("\n");
		t=97+i;
		c[i].data=t;
	}
	return;
}

int main()
{
    int i=0,n,j,k;
    scanf("%d",&n);
    char id[10],ma[100];
	int w[10];
	for (i=0;i<n;i++)
	{
		scanf("%d",&w[i]);
		printf("%d ",w[i]);
	}
	scanf("%10s",id);

	for(i=0;id[i]!='\0';i++)
        printf("%c",id[i]);
	scanf("%100s",ma);
	for(i=0;ma[i]!='\0';i++)
        printf("%c",ma[i]);

    return 0;
}
