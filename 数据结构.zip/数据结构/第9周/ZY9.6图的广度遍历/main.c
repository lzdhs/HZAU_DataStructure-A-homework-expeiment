#include <stdio.h>
#include <stdlib.h>

int visited[50];
typedef struct arcnode
{
    int num;
    struct arcnode *next;
}arcnode;//zhongjian

typedef struct vernode
{
    int data;
    arcnode *firstarc;
}vernode;//dingdian

typedef struct
{
    vernode ver[50];
    int vexnum,arcnum;
}graph;

void BFS(graph *g,int n)
{
    arcnode *p;
    int i;
    for(i=1;i<=n;i++)
    {
        if(!visited[i])
        {
             printf("%d ",g->ver[i].data);
             visited[i]=1;
             p=g->ver[n].firstarc;
        }

        while(p)
        {
            if(!visited[p->num])
            {
                printf("%d ",p->num);
                visited[p->num]=1;
            }
            p=p->next;
        }
    }
}

int main()
{
    int n,i,num,j;
    int a=0;
    scanf("%d",&n);
    graph g;

    for(i=1;i<=n;i++)
    {
        scanf("%d",&num);
        g.ver[i].data=num;
        visited[i]=0;
        g.ver[i].firstarc=NULL;
    }

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            scanf("%d",&num);
            if(num)
            {
                arcnode *p=(arcnode*)malloc(sizeof(arcnode));
                p->num=j;
                p->next=g.ver[a].firstarc;
                g.ver[a].firstarc=p;

            }
        }
    }

    BFS(&g,n);
    return 0;
}

