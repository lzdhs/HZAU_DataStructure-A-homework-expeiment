#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    char data;
    struct node *lchild;
    struct node *rchild;
}node,*tree;

void createtree(tree *bt)
{
    char ch;
    ch=getchar();
    if(ch=='.')
        *bt=NULL;
    else
    {
        *bt=(tree)malloc(sizeof(node));
        (*bt)->data=ch;
        createtree(&((*bt)->lchild));
        createtree(&((*bt)->rchild));
    }
}

void print(tree root,int n)
{
    if(!root)return;
    print(root->rchild,n+1);
    int i;
    for(i=0;i<n;i++)
        printf(" ");
    printf("%c\n",root->data);
    print(root->lchild,n+1);
}

int main()
{
    tree root;
    createtree(&root);
    print(root,1);
    return 0;
}
/*
..C
....F
...E
.A
...D
..B*/
