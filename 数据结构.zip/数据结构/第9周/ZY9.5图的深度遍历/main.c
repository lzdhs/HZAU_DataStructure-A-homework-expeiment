#include <stdio.h>
#include <stdlib.h>

int visited[50];
typedef struct arcnode
{
    int num;
    struct arcnode *next;
}arcnode;//zhongjian

typedef struct vernode
{
    int data;
    arcnode *firstarc;
}vernode;//dingdian

typedef struct
{
    vernode ver[50];
    int vexnum,arcnum;
}graph;

void DFS(graph *g,int n,int *order)
{
    arcnode *p;
    int i;
    visited[n]=1;
    (*order)++;
    printf("%d ",g->ver[n].data);
    p=g->ver[n].firstarc;
    while(p)
    {
        i=p->num;
        if(!visited[i])
            DFS(g,i,order);
        p=p->next;
    }
}

int main()
{
    int n,i,num;
    int a=0,b=0,order=0;
    scanf("%d",&n);
    graph g;
    //vernode v[50];

    for(i=1;i<=n;i++)
    {
        scanf("%d",&num);
        g.ver[i].data=num;
        visited[i]=0;
        g.ver[i].firstarc=NULL;
    }

    while(1)
    {
        scanf("%d %d",&a,&b);
        if(a==-1&&b==-1)break;
        arcnode *p=(arcnode*)malloc(sizeof(arcnode));
        p->num=b;
        p->next=g.ver[a].firstarc;
        g.ver[a].firstarc=p;
        //printf("%d,",g.ver[a].firstarc->num);
    }

    DFS(&g,1,&order);
    return 0;
}
