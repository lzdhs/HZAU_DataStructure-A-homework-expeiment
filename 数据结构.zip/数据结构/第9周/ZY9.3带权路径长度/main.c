#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int weight,parent,lchild,rchild;
}node,*tree;

int j,k;
int cal(node root[],int n);

void s(tree t, int n)
{
    int i,min1=0,min2=0;
    for(i=1;i<=n;i++)
    {
        if(t[i].parent==0&&t[i].weight>=0)
        {
            if(t[i].weight<t[min1].weight)
            {
                min2=min1;
                min1=i;
            }
            else if(t[i].weight<t[min2].weight)
            {
                min2=i;
            }
        }
    }
    j=min1;k=min2;
}

void createtree(node root[],int w[],int n)
{
    root[0].weight=10004;
    int i;
    for(i=1;i<=n;i++)
    {
        root[i].weight=w[i];
        root[i].parent=root[i].lchild=root[i].rchild=0;
    }
    int m=2*n-1;
    for(i=n+1;i<=m;i++)
    {
        root[i].weight=root[i].parent=root[i].lchild=root[i].rchild=0;
    }

    for(i=n+1;i<=m;i++)
    {
        s(root,i-1);
        root[i].weight=root[j].weight+root[k].weight;
        root[j].parent=i;
        root[k].parent=i;
        root[i].lchild=j;
        root[i].rchild=k;
    }
    int sum=cal(root,n);
    printf("%d",sum);
}

int cal(node root[], int n)
{
    int wpl=0,i;
    for(i=1;i<=n;i++)
    {
        if (root[i].lchild==0&&root[i].rchild==0)
        {
            int current=i,depth=-1;
            while(root[current].weight!=10004)
            {
                current=root[current].parent;
                depth++;
            }
            //printf("w=%d,dep=%d ",root[i].weight,depth);
            wpl+=root[i].weight*depth;
        }
    }
    return wpl;
}


int main()
{
    int n;
    scanf("%d",&n);
    node t[20];
    int a[20],i;
    for(i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    createtree(t,a,n);
    return 0;
}

