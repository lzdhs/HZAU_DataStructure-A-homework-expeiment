#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    char data;
    struct node *lchild;
    struct node *rchild;
    int ltag,rtag;
}node,*tree;

tree pre=NULL;
void createtree(tree *bt)
{
    char ch;
    ch=getchar();
    if(ch=='#')
        *bt=NULL;
    else
    {
        *bt=(tree)malloc(sizeof(node));
        (*bt)->ltag=(*bt)->rtag=0;
        (*bt)->data=ch;
        createtree(&((*bt)->lchild));
        createtree(&((*bt)->rchild));
    }
}

void thread(tree cur)
{
    if(cur)
    {
        thread(cur->lchild);
        if(cur->lchild==NULL)
        {
            cur->lchild=pre;
            cur->ltag=1;
        }
        if(pre!=NULL&&pre->rchild==NULL)
        {
            pre->rchild=cur;
            pre->rtag=1;
        }
        pre=cur;
        thread(cur->rchild);
    }
}

void bl(tree root)
{
	tree p=root->lchild;
	while(p!=root&&p)
	{
        while(p->ltag==0)
		{
		     p=p->lchild;
		}
		printf("%c",p->data);
		while(p->rtag==1&&p!=NULL)
		{
		    p=p->rchild;
			printf("%c",p->data);
		}
		p=p->rchild;
	}
	//printf("%c",p->data);
}

int main()
{
    tree root;
    createtree(&root);
    thread(root);
    bl(root);
    return 0;
}
