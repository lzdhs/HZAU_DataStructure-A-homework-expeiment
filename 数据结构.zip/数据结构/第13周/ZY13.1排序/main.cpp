#include <iostream>

using namespace std;

void bubblesort(int a[],int n)
{
    int i,j,temp;
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(a[j]<a[i])
            {
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        }
    }
}

void selectsort(int a[],int n)
{
    int i,j,k,temp;
    for(i=0;i<n-1;i++)
    {
        k=i;
        for(j=i+1;j<n;j++)
        {
            if(a[j]<a[k])
                k=j;
        }
        if(k!=i)
        {
            temp=a[i];
            a[i]=a[k];
            a[k]=temp;
        }
    }
}

int qkpass(int a[],int low,int high)
{
    int x=a[low];
    while(low<high)
    {
        while(low<high && a[high]>=x)
            high--;
        if(low<high)
        {
            a[low]=a[high];
            low++;
        }
        while(low<high && a[low]<x)
            low++;
        if(low<high)
        {
            a[high]=a[low];
            high--;
        }
    }
    a[low]=x;
    return low;
}

void qksort(int a[],int low,int high)
{
    int pos;
    if(low<high)
    {
        pos=qkpass(a,low,high);
        qksort(a,low,pos-1);
        qksort(a,pos+1,high);
    }
}
int main()
{
    int n=1,cnt=0,a[50],i;
    while(1)
    {
        cin>>n;
        if(!n)
            break;
        a[cnt++]=n;
    }
    qksort(a,0,cnt-1);
    for(i=0;i<cnt;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
    for(i=0;i<cnt;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
    for(i=0;i<cnt;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
    return 0;
}
