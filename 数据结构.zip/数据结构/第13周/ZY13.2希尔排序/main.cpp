#include <iostream>

using namespace std;

void shellinsert(int a[],int n,int step)
{
    int i,j,temp;
    for(i=step;i<n;i++)
    {
        if(a[i]<a[i-step])
        {
            temp=a[i];
            for(j=i-step;j>=0&&temp<a[j];j-=step)
                a[j+step]=a[j];
            a[j+step]=temp;
        }
    }
    for(i=0;i<n;i++)
        cout<<a[i]<<" ";
    cout<<endl;
}

void shellsort(int a[],int n,int step[],int m)
{
    int i;
    for(i=0;i<m;i++)
    {
        shellinsert(a,n,step[i]);
    }
}

int main()
{
    int n,a[100],i=0,j=0,step[3];
    while(1)
    {
        cin>>n;
        if(!n)
            break;
        a[i++]=n;
    }
    for(j=0;j<3;j++)
    {
        cin>>step[j];
    }
    shellsort(a,i,step,3);
    return 0;
}
