#include <iostream>

using namespace std;

void Merge(int a[],int low,int mid,int high)
{
    int i,j,k;
    int *s=(int*)malloc(sizeof(int)*(high-low+1));
    i=low;j=mid+1;k=0;
    while((i<=mid) && (j<=high))
    {
        if(a[i]<=a[j])
        {
            s[k]=a[i];
            i++;
            k++;
        }
        else
        {
            s[k]=a[j];
            k++;
            j++;
        }
    }

    while(i<=mid)
    {
        s[k]=a[i];
        k++;
        i++;
    }
    while(j<=high)
    {
        s[k]=a[j];
        k++;
        j++;
    }

    for(i=low,k=0;i<=high;i++,k++)
        a[i]=s[k];
    free(s);
}

void mergesort(int a[],int low,int high)
{
    int mid;
    if(low<high)
    {
        mid=(high+low)/2;
        mergesort(a,low,mid);
        mergesort(a,mid+1,high);
        Merge(a,low,mid,high);
    }
}

int main()
{
    int n,i=1,a[50],j;
    while(1)
    {
        cin>>n;
        if(n==-1)
            break;
        a[i++]=n;
    }
    i--;
    mergesort(a,1,i);
    for(j=1;j<=i;j++)
        cout<<a[j]<<" ";
    return 0;
}
