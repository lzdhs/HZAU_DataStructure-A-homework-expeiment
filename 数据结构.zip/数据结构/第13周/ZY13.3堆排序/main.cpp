#include <iostream>

using namespace std;

void sift(int a[],int k,int m)
{
    int t=a[k];
    int x=a[k];
    int i=k;
    int j=2*i;
    while(j<=m)
    {
        if(j+1<=m && a[j]<a[j+1])
        {
            j++;
        }
        if(x>=a[j])
            break;
        else
        {
            a[i]=a[j];
            i=j;
            j=2*i;
        }
    }
    a[i]=t;
}

void crtheap(int a[],int n)
{
    int i;
    for(i=n/2;i>=1;i--)//1
    {
        sift(a,i,n);
    }
}

void heapsort(int a[],int n)
{
    crtheap(a,n);
    int b,i,j;
    for(i=n;i>=2;i--)
    {
        for(j=1;j<=n;j++)
            cout<<a[j]<<" ";
        cout<<endl;
        b=a[1];
        a[1]=a[i];
        a[i]=b;
        sift(a,1,i-1);
    }
}

int main()
{
    int n,a[50],i=1,j;
    while(1)
    {
        cin>>n;
        if(!n)
            break;
        a[i++]=n;
    }
    i--;
    heapsort(a,i);
    for(j=1;j<=i;j++)
            cout<<a[j]<<" ";
        cout<<endl;
    return 0;
}
