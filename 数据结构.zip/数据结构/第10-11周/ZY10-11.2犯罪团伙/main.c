#include <stdio.h>
#include <stdlib.h>

int visited[1000];

typedef struct arcnode
{
    int num;
    struct arcnode *next;
}arcnode;//zhongjian

typedef struct vernode
{
    int data;
    arcnode *firstarc;
}vernode;//dingdian

typedef struct
{
    vernode ver[1000];
    int vexnum,arcnum;
}graph;

void DFS(graph *g,int n)
{
    arcnode *p;
    int i;
    visited[n]=1;
    p=g->ver[n].firstarc;
    while(p)
    {
        i=p->num;
        if(!visited[i])
            DFS(g,i);
        p=p->next;
    }
}

int main()
{
    int n1,n2,i,p1,p2,cnt=0;
    graph g;
    scanf("%d",&n1);
    scanf("%d",&n2);

    for(i=1;i<=n1;i++)
    {
        g.ver[i].data=i;
        visited[i]=0;
        g.ver[i].firstarc=NULL;
    }

    for(i=1;i<=n2;i++)
    {
        scanf("%d %d",&p1,&p2);
        arcnode *p=(arcnode*)malloc(sizeof(arcnode));
        p->num=p2;
        p->next=g.ver[p1].firstarc;
        g.ver[p1].firstarc=p;

        p=(arcnode*)malloc(sizeof(arcnode));
        p->num=p1;
        p->next=g.ver[p2].firstarc;
        g.ver[p2].firstarc=p;
    }

    for(i=1;i<=n1;i++)
    {
        if(!visited[i])
        {
            DFS(&g,i);
            cnt++;
        }
    }
    printf("%d",cnt);
    return 0;
}
