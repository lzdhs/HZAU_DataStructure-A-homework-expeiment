#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int x1,x2,y1,y2;
    int no;
}window;
window win[10];

void exchange(int pos,int wincount)
{
    int i;
    window temp;
    temp=win[pos];
    for(i=pos+1;i<=wincount;i++)
    {
        win[i-1]=win[i];
    }
    win[wincount]=temp;
}

int main()
{
    int wincount,cnt,i,j,flag;
    int X1,X2,Y1,Y2;
    scanf("%d",&wincount);
    scanf("%d",&cnt);
    for(i=1;i<=wincount;i++)
    {
        scanf("%d %d %d %d",&X1,&Y1,&X2,&Y2);
        win[i].no=i;
        win[i].x1=X1;
        win[i].x2=X2;
        win[i].y1=Y1;
        win[i].y2=Y2;
    }

    for(i=1;i<=cnt;i++)
    {
        scanf("%d %d",&X1,&Y1);
        flag=1;
        for(j=wincount;j>=1;j--)
        {
            if(win[j].x1<=X1&&win[j].x2>=X1&&win[j].y1<=Y1&&win[j].y2>=Y1)
            {
                printf("%d\n",win[j].no);
                flag=0;
                exchange(j,wincount);
                break;
            }
        }

        if(flag)
            printf("IGNORED\n");

    }
    return 0;
}
