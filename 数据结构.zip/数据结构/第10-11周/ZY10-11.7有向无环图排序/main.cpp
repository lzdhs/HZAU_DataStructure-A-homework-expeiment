#include <iostream>
#include <stack>
using namespace std;

int a[50];
int n=0;
typedef struct arcnode
{
    int adjvex;
    struct arcnode *next;
}arcnode;

typedef struct vernode
{
    int data;
    arcnode *first;
}vernode;

typedef struct
{
    vernode ver[50];
    int vexnum,arcnum;
}graph;


void findid(graph &g,int indegree[])//求入度
{
    int i;
    arcnode *p;
    for(i=0;i<g.vexnum;i++)//初始化入度数组
        indegree[i]=0;
    for(i=0;i<g.vexnum;i++)
    {
        p=g.ver[i].first;//求每个顶点的入度
        while(p)
        {
            indegree[p->adjvex]++;//p指向的点入度+1，不停循环
            p=p->next;
        }
    }
}

void topsort(graph &g)
{
    stack<int> s;//此处偷懒了，调用stl，如果考试的时候不让用请使用前面栈操作来替换
    int indegree[50];
    int i,cnt,k;
    arcnode *p;
    findid(g,indegree);//求入度
    for(i=0;i<g.vexnum;i++)
    {
        if(!indegree[i])//入度为0则进栈
            s.push(i);
    }
    cnt=0;
    while(!s.empty())
    {
        i=s.top();
        a[n++]=i;//先存到数组中，一会一起输出
        s.pop();//出栈
        cnt++;
        p=g.ver[i].first;
        while(p)
        {
            k=p->adjvex;
            indegree[k]--;//删掉节点对应的边
            if(!indegree[k])//入度为0就进栈
                s.push(k);
            p=p->next;
        }
    }
    if(cnt < g.vexnum)
        cout<<"ERROR";
    else
    {
        for(i=0;i<n;i++)
            cout<<a[i]<<" ";
    }
}

int main()
{
    graph g;
    int i,j,n;
    arcnode *p,*q;
    cin>>g.vexnum;
    for(i=0;i<g.vexnum;i++)//初始化
    {
        g.ver[i].first=NULL;
        g.ver[i].data=i;
    }
    for(i=0;i<g.vexnum;i++)//尾插法创建图
    {
        for(j=0;j<g.vexnum;j++)
        {
            cin>>n;
            if(n && g.ver[i].first==NULL)
            {
                p=new arcnode;
                p->adjvex=j;
                g.ver[i].first=p;
                p->next=NULL;
            }
            else if(n)
            {
                q=g.ver[i].first;
                while(q->next)
                    q=q->next;
                p=new arcnode;
                q->next=p;
                p->next=NULL;
                p->adjvex=j;
            }
        }
    }
    topsort(g);
    return 0;
}
