#include <stdio.h>
#include <stdlib.h>

int visited[50];
int a[50][50];
int n;

void DFS(int a[][50],int b)
{
    visited[b]=1;
    int i;
    for(i=1;i<=n;i++)
    {
        if(!visited[i]&&a[b][i]==1)
            DFS(a,i);
    }
}
int main()
{
    int i,j,cnt=0;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        visited[i]=0;
        for(j=1;j<=n;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    for(i=1;i<=n;i++)
    {
        if(!visited[i])
        {
            DFS(a,i);
            cnt++;
        }
    }
    printf("%d",cnt);
    return 0;
}
