#include <stdio.h>
#include <stdlib.h>

typedef struct
{
	int vertex[100];
	int graph[100][100];
	int vexnum,arcnum;
}Graph;

int sum=0;

typedef struct
{
	int adjvex;
	int lowcost;
}shortedge;

int locate(Graph *G,int v)
{
	int i;

	for(i=0;i<G->vexnum;i++)
	{
		if(v==G->vertex[i])
		{
			return i;
		}
	 }
	 return -1;
}

void create(Graph *G)
{
	int i,j;
	scanf("%d %d",&G->vexnum,&G->arcnum);
	for(i=0;i<G->vexnum;i++)
    {
        G->vertex[i]=i+1;
    }

	for(i=0;i<G->vexnum;i++)
        for(j=0;j<G->vexnum;j++)
	    {
	    	G->graph[i][j]=32767;
		}

	 int n,m;
	 int v1,v2;
	 int w;

	 for(i=0;i<G->arcnum;i++)
	 {
	 	scanf(" %d %d %d",&v1,&v2,&w);
	 	n=locate(G,v1);
	 	m=locate(G,v2);
	    G->graph[n][m]=w;
	    G->graph[m][n]=w;
     }
}

int mini(Graph *G,shortedge *s)
{
	int i;
	int min,loc;

	min=32767;
	for(i=1;i<G->vexnum;i++)
	{
		if(min>s[i].lowcost&&s[i].lowcost!=0)
		{
			min=s[i].lowcost;
			loc=i;
		}
	}
	return loc;
}

void prim(Graph *G,int start)
{
	int i,j,k;
	shortedge s[100];

	k=locate(G,start);
	for(i=0;i<G->vexnum;i++)
	{
		s[i].adjvex=start;
		s[i].lowcost=G->graph[k][i];
	}
	s[k].lowcost=0;

	for(i=0;i<G->vexnum-1;i++)
	{
		k=mini(G,s);

	    printf("%d-%d:%d\n",s[k].adjvex,G->vertex[k],s[k].lowcost);
	    sum+=s[k].lowcost;
	    s[k].lowcost=0;

	    for(j=0;j<G->vexnum;j++)
	    {
	    	if(G->graph[k][j]<s[j].lowcost)
	    	{
	    		s[j].lowcost=G->graph[k][j];
	    		s[j].adjvex=G->vertex[k];
			}
		}

	 }
}


int main()
{
	Graph G;
	create(&G);
	prim(&G,1);
    printf("%d",sum);
	return 0;
}
