#include <iostream>

using namespace std;

typedef struct
{
    int vexnum,edgenum;
    int matrix[50][50];
}graph;

int dist[50][50];
int path[50][50];
void flyd(graph g)
{
    int i,j,k;

    for(i=0; i<g.vexnum; i++)
    {
        for(j=0; j<g.vexnum; j++)
        {
            dist[i][j]=g.matrix[i][j];//��ʼ��
            if(i != j && path[i][j] != 9999)
                path[i][j]=j;
        }
        path[i][i]=0;
        dist[i][i]=0;
    }

    for(k=0; k<g.vexnum; k++)
    {
        for(i=0; i<g.vexnum; i++)
        {
            for(j=0; j<g.vexnum; j++)
            {
                if(dist[i][k] == 9999 || dist[k][j] == 9999)
                    continue;
                if(dist[i][j] > (dist[i][k]+dist[k][j]))
                {
                    dist[i][j]=dist[i][k]+dist[k][j];
                    path[i][j]=path[i][k];
                }
            }
        }
    }
    for(i=0;i<g.vexnum;i++)
    {
        for(j=0;j<g.vexnum;j++)
        {
            cout<<"from "<<i<<" to "<<j<<": dist = "<<dist[i][j];
            k=i;
            cout<<" path:";
            while(k!=j)
            {
                cout<<k<<" ";
                k=path[k][j];
            }
            cout<<j<<" "<<endl;
        }
    }

}
int main()
{
    int i,j;
    graph g;
    cin>>g.vexnum;
    for(i=0;i<g.vexnum;i++)
    {
        for(j=0;j<g.vexnum;j++)
        {
            cin>>g.matrix[i][j];
        }
    }
    flyd(g);
    return 0;
}
