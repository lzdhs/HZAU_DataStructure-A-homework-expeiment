#include <iostream>
#include <stack>
using namespace std;

typedef struct arcnode
{
    int adjvex,weight;
    struct arcnode *next;
}arcnode;

typedef struct vernode
{
    int indegree,est,lst;
    arcnode *first;
}vernode;

typedef struct
{
    vernode ver[50];
    int vexnum,arcnum;
}graph;

int ve[50];

void findid(graph &g,int indegree[])
{
    int i;
    arcnode *p;
    for(i=0;i<g.vexnum;i++)
        indegree[i]=0;
    for(i=0;i<g.vexnum;i++)
    {
        p=g.ver[i].first;
        while(p)
        {
            indegree[p->adjvex]++;
            p=p->next;
        }
    }
}

stack<int> toporder(graph &g)
{
    int cnt,i,j,k;
    arcnode *p;
    stack <int> t,s;
    int indegree[50];
    findid(g,indegree);
    for(i=0;i<g.vexnum;i++)
    {
        if(!indegree[i])
            s.push(i);
    }
    cnt=0;
    for(i=0;i<g.vexnum;i++)
    {
        ve[i]=0;
    }

    while(!s.empty())
    {
        j=s.top();
        s.pop();
        t.push(j);
        cnt++;
        p=g.ver[j].first;
        while(p)
        {
            k=p->adjvex;
            if(--indegree[k]==0)
                s.push(k);
            if(ve[j]+p->weight > ve[k])
                ve[k]=ve[j]+p->weight;
            p=p->next;
        }
    }
    return t;
}

void criticlpath(graph &g)
{
    arcnode *p;
    int i,j,k,dut,ei,li;
    int vl[50];
    stack<int> t;
    t=toporder(g);
    for(i=0;i<g.vexnum;i++)
    {
        vl[i]=ve[g.vexnum-1];
    }
    while(!t.empty())
    {
        j=t.top();
        t.pop();
        p=g.ver[j].first;
        while(p)
        {
            k=p->adjvex;
            dut=p->weight;
            if(vl[k]-dut < vl[j])
                vl[j]=vl[k]-dut;
            p=p->next;
        }
    }
    cout<<ve[g.vexnum-1]<<endl;
    for(j=0;j<g.vexnum;j++)
    {
        p=g.ver[j].first;
        while(p)
        {
            k=p->adjvex;
            dut=p->weight;
            ei=ve[j];
            li=vl[k]-dut;
            if(ei ==li)
            {
                cout<<j<<" "<<k<<endl;
            }
            p=p->next;
        }
    }
}

int main()
{
    graph g;
    cin>>g.vexnum>>g.arcnum;
    int i,start,end_,weight,temp=-1;
    for(i=0;i<g.vexnum;i++)
    {
        g.ver[i].first=NULL;
    }
    arcnode *p,*q;
    for(i=0;i<g.arcnum;i++)
    {
        cin>>start>>end_>>weight;
        if(start == temp)
        {
            q=g.ver[start].first;
            while(q->next)
                q=q->next;
            p = new arcnode{end_, weight, g.ver[start].first};
            p->next=NULL;
            q->next=p;
            g.ver[end_].indegree++;
        }
        else
        {
            p = new arcnode{end_, weight, g.ver[start].first};
            temp=start;
            g.ver[start].first = p;
            g.ver[end_].indegree++;
        }
    }
    criticlpath(g);
    return 0;
}
