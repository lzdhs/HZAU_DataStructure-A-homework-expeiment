#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int ver[100];
    int graph[100][100];
    int vexnum,arcnum;
}Graph;

typedef struct
{
    int adjvex;
    int low;
}shortedge;

int locate(Graph *g,int n)
{
    int i;
    for(i=1;i<=g->vexnum;i++)
    {
        if(n==g->ver[i])
            return i;
    }
    return -1;
}

void creategraph(Graph *g)
{
    int i,j;
    scanf("%d %d",&g->vexnum,&g->arcnum);
    for(i=1;i<=g->vexnum;i++)
    {
        for(j=1;j<=g->vexnum;j++)
        {
            g->graph[i][j]=(i==j)?0:32767;
        }
    }

    int m,n;
    int num1,num2,weigh;
    for(i=1;i<=g->arcnum;i++)
    {
        scanf("%d %d %d",&num1,&num2,&weigh);
        n=locate(g,num1);
        m=locate(g,num2);
        g->graph[n][m]=weigh;
        g->graph[m][n]=weigh;
    }
}

int mini(Graph *g,shortedge *s)
{
    int i,min,loc=-1;
    min=32767;
    for(i=1;i<=g->vexnum;i++)
    {
        if(min>s[i].low&&s[i].low!=0)
        {
            min=s[i].low;
            loc=i;
        }
    }
    return loc;
}

void prim(Graph *g,int n)
{
    int i,j,k;
    shortedge s[100];
    int visited[100]={0};

    k=locate(g,n);
    for(i=1;i<=g->vexnum;i++)
    {
        s[i].adjvex=i;
        s[i].low=g->graph[n][i];
    }
    visited[n]=1;
    //s[k].low=0;

    for(k=1;k<g->vexnum;k++)
    {
        j=mini(g,s);
        if(visited[j]==0)
        {
            printf("%d-%d:%d\n",s[k].adjvex,g->ver[k],s[k].low);
            visited[j]=1;
            for(i=1;i<=g->vexnum;i++)
            {
                if(!visited[i] && g->graph[j][i]<s[i].low)
                {
                    s[i].low=g->graph[j][i];
                    s[i].adjvex=j;
                }
            }
        }
    }
}

int main()
{
    Graph g;
    creategraph(&g);
    prim(&g,1);
    return 0;
}
