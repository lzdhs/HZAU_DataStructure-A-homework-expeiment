#include <iostream>

using namespace std;

typedef struct
{
    int a[10000];
    int b[10000];
    //int last;
}seqlist;

int main()
{
    int ballcount,length,time=0,i,j,ballnum,pos;
    cin>>ballcount;
    cin>>length;
    cin>>time;
    seqlist ball;

    for(ballnum=1;ballnum<=ballcount;ballnum++)
    {
        ball.b[ballnum]=1;
        cin>>pos;
        ball.a[ballnum]=pos;
        if(pos==0)
        {
            ball.b[ballnum]=-1;
        }
    }

    for(i=0;i<time;i++)
    {
        for(ballnum=1;ballnum<=ballcount;ballnum++)
        {

            if(ball.a[ballnum]==length||ball.a[ballnum]==0)
            {
                ball.b[ballnum]=-ball.b[ballnum];
            }

            for(j=1;j<=ballcount;j++)
            {
                if(ball.a[j]==ball.a[ballnum])
                {
                    ball.b[j]=-ball.b[j];
                    ball.b[ballnum]=-ball.b[ballnum];
                }
            }
            ball.a[ballnum]+=ball.b[ballnum];

        }
    }

    for(i=1;i<=ballcount;i++)
    {
        cout<<ball.a[i]<<" ";
    }
    return 0;
}

