#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
}node,*linklist;

void initlist(linklist *a)
{
    *a=(linklist)malloc(sizeof(node));
    (*a)->next=NULL;
}

void createfromtail(linklist a)
{
    int n=1;
    node *r,*s;
    r=a;
    while(1)
    {
        scanf("%d",&n);
        if(n==0)break;
        s=(node *)malloc(sizeof(node));
        s->data=n;
        r->next=s;
        r=s;
    }
    r->next=NULL;
}

void bubblesort(linklist a)
{
    node *current,*nextnode;
    int flag=0,temp;
    do
    {
        current=a->next;
        flag=0;
        while(current->next!=NULL)
        {
            nextnode=current->next;
            if(current->data>nextnode->data)
            {
                temp=current->data;
                current->data=nextnode->data;
                nextnode->data=temp;
                flag=1;
            }
            current=current->next;
        }
    }while(flag);
}

void show(linklist a)
{
    node *p=a->next;
    while(p!=NULL)
    {
        printf("%d ",p->data);
        p=p->next;
    }
}

int main()
{
    linklist a;
    initlist(&a);
    createfromtail(a);
    bubblesort(a);
    show(a);
    return 0;
}
