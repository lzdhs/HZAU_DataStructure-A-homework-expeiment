#include <iostream>
#include <cmath>
using namespace std;

typedef struct
{
    long int a[10000];
    long int b[10000];
    long int c[10000];
    int alast;
    int blast;
    int clast;
}seqlist;

int main()
{
    seqlist wnx;
    int i,j,k,duan,temp;
    cin>>wnx.alast>>wnx.blast>>wnx.clast;
    for(i=0;i<wnx.alast;i++)
    {
        cin>>wnx.a[i];
    }
    for(i=0;i<wnx.blast;i++)
    {
        cin>>wnx.b[i];
    }
    for(i=0;i<wnx.clast;i++)
    {
        cin>>wnx.c[i];
    }
    duan=10000;
    for(i=0;i<wnx.alast;i++)
    {
        for(j=0;j<wnx.blast;j++)
        {
            for(k=0;k<wnx.clast;k++)
            {
                temp=abs(wnx.a[i]-wnx.b[j])+abs(wnx.b[j]-wnx.c[k])+abs(wnx.c[k]-wnx.a[i]);
                if(temp<duan)
                {
                    duan=temp;
                }
            }
        }
    }
    cout<<duan;
    return 0;
}
