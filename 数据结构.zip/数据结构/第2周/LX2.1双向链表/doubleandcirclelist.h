#ifndef DOUBLEANDCIRCLELIST_H_INCLUDED
#define DOUBLEANDCIRCLELIST_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

/*content
init
create
bianli
merge
add
delete
*/
typedef struct node
{
    int data;
    struct node *next;
}node,*linklist;

typedef struct dnode
{
    int data;
    node *prior;
    node *next;
}dnode,*LinkList;

void init(linklist *a)
{
    *a=(node*)malloc(sizeof(node));
    (*a)->next=NULL;
}

void create(linklist a)
{
    node *r,*s;
    r=a;
    //r->prior=NULL
    int n=1;
    while(1)
    {
        scanf("%d",&n);
        if(!n)break;
        s=(node*)malloc(sizeof(node));
        s->data=n;
        //s->prior=r
        r->next=s;
        r=s;
    }
    r->next=a;//NULL
}

void bianli(linklist a)
{
    node *p=a->next;
    do
    {
        printf("%d ",p->data);
        p=p->next;
    }while(p!=a);
}

void mer(linklist a,linklist b)
{
    node *p,*q;
    while(p->next!=a)p=p->next;
    while(q->next!=b)q=q->next;
    p->next=b;
    q->next=a;
}

void add(LinkList a,int i,int e)
{
    dnode *p=a,s;
    for(int j=0;j<i;j++)
    {
        p=p->next;
    }
    s=(dnode*)malloc(sizeof(dnode));
    s->data=e;
    s->next=p->next;
    s->prior=p;
    p->next->prior=s;
    p->next=s;
}

void del(LinkList a,int i)
{
    dnode *p=a;
    for(int j=0;j<i;j++)
    {
        p=p->next;
    }
    p->prior->next=p->next;
    p->next->prior=p->prior'
}

#endif // DOUBLEANDCIRCLELIST_H_INCLUDED
