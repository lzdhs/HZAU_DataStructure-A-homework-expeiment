#include <stdio.h>
#include <stdlib.h>
#include "doubleandcirclelist.h"
/*typedef struct dnode
{
    int data;
    struct dnode *prior;
    struct dnode *next;
}dnode,*linklist;*/

void init(LinkList *l)
{
    *l=(dnode*)malloc(sizeof(dnode));
    (*l)->next=NULL;
    (*l)->prior=NULL;
}

void create(linklist l)
{
    int n=1;
    dnode *r,*s;
    r=l;
    while(1)
    {
        scanf("%d",&n);
        if(n==0)break;
        s=(dnode*)malloc(sizeof(dnode));
        s->data=n;
        s->prior=r;
        r->next=s;
        r=s;
    }
    s->next=NULL;
}

void showlist(linklist L)
{
    dnode *current=L->next;
    while(current!=NULL)
    {
        printf("%d ",current->data);
        current=current->next;
    }
}

void add(linklist a,int n,int i)
{
    dnode *s,*newnode;
    int j=1;
    s=a->next;
    while(s->next!=NULL&&j!=i)//panduancharuweizhi
    {
        j++;
        s=s->next;
    }
    newnode=(linklist)malloc(sizeof(dnode));
    newnode->data=n;
    newnode->next=s->next;
    newnode->prior=s->prior;
    s->next=newnode;
    newnode->next->prior=newnode;
}
int main()
{
    linklist a;
    init(&a);
    create(a);
    add(a,3,5);
    showlist(a);
    return 0;
}
