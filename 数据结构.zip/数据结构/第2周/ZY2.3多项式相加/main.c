#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    float xishu;
    int zhishu;
    struct node *next;
}node,*linklist;

void initlist(linklist *a)
{
    *a=(node*)malloc(sizeof(node));
    (*a)->next=NULL;
}

void createfromtail(linklist a,int count)
{
    node *r,*s;
    r=a;
    while(count)
    {
        s=(node *)malloc(sizeof(node));
        scanf("%f %d",&s->xishu,&s->zhishu);
        r->next=s;
        r=s;
        count--;
    }
    r->next=NULL;
}

int length(linklist *a)
{
    int i=1;
    node *p=(*a)->next;
    while(p->next!=NULL)
    {
        i++;
        p=p->next;
    }
    return i;
}

void sort(linklist *l)
{
    int tempz,i;
    float tempx;
    node *current=(*l)->next,*nextnode;
    for(i=0;i<length(&(*l))-1;i++)
    {
        nextnode=current;
        do
        {
            nextnode=nextnode->next;
            if(nextnode->zhishu>current->zhishu)
            {
                tempz=current->zhishu;
                current->zhishu=nextnode->zhishu;
                nextnode->zhishu=tempz;

                tempx=current->xishu;
                current->xishu=nextnode->xishu;
                nextnode->xishu=tempx;
            }
        }while(nextnode->next!=NULL);
        current=current->next;
    }
}

void add(linklist a,linklist b)
{
    node *pa=a,*pb=b->next,*temp;
    int flag=1;
    do
    {
        pa=pa->next;
        pb=b->next;
        while(1)
        {
            if(pb->zhishu==pa->zhishu)
            {
                pa->xishu+=pb->xishu;
            }
            if(pb->next==NULL)break;
            pb=pb->next;
        }
    }while(pa->next!=NULL);
    pb=b->next;
    do
    {
        flag=1;
        pa=a;
        do
        {
            pa=pa->next;
            if(pa->zhishu==pb->zhishu)
            {
                flag=0;
                break;
            }
        }while(pa->next!=NULL);
        if(flag)
        {
            temp=(node*)malloc(sizeof(node));
            pa->next=temp;
            temp->xishu=pb->xishu;
            temp->zhishu=pb->zhishu;
            temp->next=NULL;
        }
        pb=pb->next;
    }while(pb!=NULL);
}

void del(linklist *l)
{
    node *p=*l;
    do
    {
        if(p->next->xishu==0)
        {
            p->next=p->next->next;
        }
        else
        {
            p=p->next;
        }
    }while((p->next!=NULL)&&(p!=NULL));
}

int main()
{
    int n1,n2,n3;
    linklist A,B;
    scanf("%d",&n1);
    initlist(&A);
    initlist(&B);
    createfromtail(A,n1);
    scanf("%d",&n2);
    createfromtail(B,n2);
    add(A,B);
    sort(&A);
    del(&A);
    //showlist(A);
    scanf("%d",&n3);
    node *p=A;
    while(n3&&(p->next)!=NULL)
    {
        p=p->next;
        n3--;
    }
    printf("%.1f %d",p->xishu,p->zhishu);
    return 0;
}
