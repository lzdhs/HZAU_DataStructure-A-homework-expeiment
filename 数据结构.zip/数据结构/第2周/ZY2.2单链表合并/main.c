#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
}node,*linklist;

void createfromtail(linklist a)
{
    int n=1;
    node *r,*s;
    scanf("%d",&n);
    a->data=n;
    r=a;
    while(1)
    {
        scanf("%d",&n);
        if(n==0)break;
        s=(node *)malloc(sizeof(node));
        s->data=n;
        r->next=s;
        r=s;
    }
    r->next=NULL;
}

void initlist(linklist *a)
{
    *a=(node*)malloc(sizeof(node));
    (*a)->next=NULL;
}

void add(linklist *a,linklist *b)
{
    node *p1,*p2,*nod,*temp;
    if((*a)->data>(*b)->data)
    {
        nod=(node*)malloc(sizeof(node));
        temp=(*a);
        (*a)=nod;
        nod->next=temp;
        nod->data=(*b)->data;
    }
    if((*a)->data<(*b)->data)
    {
        nod=(node*)malloc(sizeof(node));
        temp=(*a)->next;
        nod=temp;
        (*a)->next=nod;
        nod->data=(*b)->data;
    }
    p1=*a;p2=*b;
    while((p1->next!=NULL)&&(p2->next!=NULL))
    {
        if(p2->next->data<p1->next->data)
        {
            nod=(node*)malloc(sizeof(node));
            nod->data=p2->next->data;
            temp=p1->next;
            p1->next=nod;
            nod->next=temp;
            p1=p1->next;
            p2=p2->next;
        }
        else if(p1->next->data==p2->next->data)
            {
                p1=p1->next;
                p2=p2->next;
            }
            else
            {
                p1=p1->next;
            }
        }
    while(p2->next!=NULL)
    {
        nod=(node*)malloc(sizeof(node));
        p1->next=nod;
        nod->data=p2->next->data;
        nod->next=p2->next->next;
        p1=p1->next;
        p2=p2->next;
    }
}

void showlist(linklist L)
{
    node *current=L;
    while(current!=NULL)
    {
        printf("%d ",current->data);
        current=current->next;
    }
}
/*void destroyList(linklist* l) {
    linklist *current=l,*next;
    while (current!=NULL)
    {
        next=(*current)->next;
        free(current);
        current=next;
    }
    l=NULL;
}*/
int main()
{
    linklist a,b;
    initlist(&a);
    initlist(&b);
    createfromtail(a);
    createfromtail(b);
    add(&a,&b);
    showlist(a);
    //destroyList(&b);
    return 0;
}
