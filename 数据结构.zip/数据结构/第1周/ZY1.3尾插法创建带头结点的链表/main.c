#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
    int data;
    struct Node *next;
}Node,*LinkList;

void createlist(LinkList L)
{
    Node *r,*s;
    int n=1;
    r=L;
    while(1)
    {
        scanf("%d",&n);
        if(n==0)break;
        s=(Node *) malloc (sizeof(Node));
        s->data=n;
        r->next=s;
        r=s;
    }
    r->next=NULL;
}

void Initlist(LinkList *L)
{
    *L=(LinkList) malloc (sizeof(Node));
    (*L)->next=NULL;
}

void showlist(LinkList L)
{
    Node *current=L->next;
    while(current!=NULL)
    {
        printf("%d ",current->data);
        current=current->next;
    }
}
int main()
{
    Node a;
    LinkList l=&a;
    Initlist(&l);
    createlist(l);
    showlist(l);
    return 0;
}

