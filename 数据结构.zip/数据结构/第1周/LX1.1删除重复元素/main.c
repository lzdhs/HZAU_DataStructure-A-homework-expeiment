#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int arr[100];
    int last;
}seqlist;

void del(seqlist *L,int i)
{
    int j;
    for(j=i;j<=L->last;j++)
    {
        L->arr[j]=L->arr[j+1];
    }
    L->last--;
}

int main()
{
    seqlist A,B,C;
    for(int i=0;i<5;i++)
    {
        scanf("%d",&A.arr[i]);
    }
    for(int i=0;i<5;i++)
    {
        scanf("%d",&B.arr[i]);
    }
    for(int i=0;i<5;i++)
    {
        scanf("%d",&C.arr[i]);
    }
    A.last=B.last=C.last=5;
    for(int i=0;i<A.last;i++)
    {
        for(int j=0;j<B.last;j++)
        {
            for(int k=0;k<C.last;k++)
                if((A.arr[i]==B.arr[j])&&(B.arr[j]==C.arr[k]))
                {
                    del(&A,i);
                }
        }
    }
    for(int i=0;i<A.last;i++)
    {
        printf("%d ",A.arr[i]);
    }
    return 0;
}
