#include <stdio.h>
#include <stdlib.h>
#define MAXSIZE 100
#define OK 1
#define ERROR 0

typedef struct
{
    int elem[MAXSIZE];
    int len;
}seqlist;

void init(seqlist *a)
{
    a->len=-1;
}

void add(seqlist *a,int n,int pos)
{
    a->len++;
    a->elem[pos]=n;
}

int ji(int n)
{
    if(n%2!=0)return OK;
    else return ERROR;
}

int main()
{
    seqlist a1;
   // seqlist a2;
    int *left=a1.elem;
    int temp;
    init(&a1);//init(&a2);

    int n,l=0;
    scanf("%d",&n);
    while(n!=0)
    {
        add(&a1,n,l);
        l++;
        scanf("%d",&n);
    }
    int *right=&(a1.elem[l-1]);

    while(left<right)
    {
        int b1=ji(*left);
        int b2=ji(*right);
        if(b1)left++;
        if(!b2)right--;
        if(!b1&&(b2))
        {
            temp=*left;
            *left=*right;
            *right=temp;
        }
    }

    for(l=0;l<=a1.len;l++)
    {
        printf("%d ",a1.elem[l]);
    }
    return 0;
}

