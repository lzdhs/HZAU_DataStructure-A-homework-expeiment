#include <stdio.h>
#include <stdlib.h>

#define MAXSIZE 20
#define OK 1
#define ERROR 0

typedef struct
{
    int elem[MAXSIZE];
    int last;
}arr;

int search(arr *a1,int n)
{
    int i=0;
    for(i=0;i<=a1->last;i++)
    {
        if(n==a1->elem[i])
        {
            return ERROR;
        }
    }
    return OK;
}

void init(arr *a)
{
    a->last=-1;
}

void add(arr *a,int n,int pos)
{
    a->last++;
    a->elem[pos]=n;
}

int main()
{
    arr a1;
    arr a2;
    init(&a1);init(&a2);

    int n,l=0,p;
    scanf("%d",&n);
    while(n!=0)
    {
        add(&a1,n,l);
        l++;
        scanf("%d",&n);
    }

    l=0;
    scanf("%d",&n);
    while(n!=0)
    {
        add(&a2,n,l);
        l++;
        scanf("%d",&n);
    }

    l=0;
    while(l<=a1.last)
    {
         p=search(&a2,a1.elem[l]);
         if(p==OK)
         {
            printf("%d ",a1.elem[l]);
         }
         l++;
    }
    return 0;
}

