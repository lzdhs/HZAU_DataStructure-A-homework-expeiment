#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
}node,*linklist;

void createfromtail(linklist a)
{
    int n=1;
    node *r,*s;
    r=a;
    while(1)
    {
        scanf("%d",&n);
        if(n==0)break;
        s=(node *)malloc(sizeof(node));
        s->data=n;
        r->next=s;
        r=s;
    }
    r->next=NULL;
}

int length(linklist a)//bianli,changdu
{
    int i=1;
    node *p=a->next;
    while(p->next!=NULL)
    {
        i++;
        p=p->next;
    }
    return i;
}

void initlist(linklist *a)
{
    *a=(node*)malloc(sizeof(node));
    (*a)->next=NULL;
}

void add(linklist a,int n,int i)
{
    node *s,*newnode;
    int j=1;
    s=a->next;
    while(s->next!=NULL&&j!=i)//panduancharuweizhi
    {
        j++;
        s=s->next;
    }
    newnode=(linklist)malloc(sizeof(node));
    newnode->data=n;
    newnode->next=s->next;
    s->next=newnode;
}

void del(linklist a,int i)
{
    node *s;
    int j=1;
    s=a->next;
    while(j!=i-1)//panduanɾ��weizhi
    {
        j++;
        s=s->next;
    }
    s->next=s->next->next;
}
void showlist(linklist L)
{
    node *current=L->next;
    while(current!=NULL)
    {
        printf("%d ",current->data);
        current=current->next;
    }
}
int main()
{
    linklist a;
    initlist(&a);
    createfromtail(a);
    showlist(a);
    del(a,5);
    showlist(a);
    return 0;
}
