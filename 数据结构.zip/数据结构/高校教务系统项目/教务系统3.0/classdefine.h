#ifndef CLASSDEFINE_H_INCLUDED
#define CLASSDEFINE_H_INCLUDED

#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

class Student;
class Teacher;
class Course;

class Teacher
{
public:
    string name;
    string ID;
    string college;
    int age;
    char sex;
    string pfstitle;//professiontitle,1:Teaching assistant,2:lecturer,3:associate professor��4��professor
    Course *teach;

    Teacher()
    {
        name="zhongmengxin";
        ID="000";
        age=18;
        pfstitle="000";
        sex='?';
        college="***";
        teach=NULL;
    }

    Teacher(string nname,string id,int aage,int title,char gender)
    {
        name=nname;
        ID=id;
        age=aage;
        sex=gender;
        //teach=t;
    }

    ~Teacher(){}

    friend ostream& operator <<(ostream& out,Teacher& s1)
    {
        out<<"ID:"<<setw(3)<<s1.ID<<" name:"<<setw(5)<<s1.name<<" age: "<<setw(1)<<s1.age<<" sex: "<<setw(1)<<s1.sex<<endl;
        return out;
    }
};

class Course
{
public:
    string name;
    string ID;
    Student *s[100];
    int stucount;
    int point;
    float jidian;
    Teacher *t;
    static int cnt;

    Course()
    {
        name="cou";
        ID="000";
        point=0;
        stucount=0;
        jidian=0;
    }

    Course(string nname,string id,int point)
    {
        name=nname;
        ID=id;
        this->point=point;
    }

    friend ostream& operator <<(ostream& out,Course& s1)
    {
        out<<"ID:"<<setw(3)<<s1.ID<<" name:"<<setw(5)<<s1.name<<" point: "<<setw(1)<<s1.point<<endl;
        return out;
    }

    ~Course(){}
};

int Course::cnt=0;

class Student
{
private:
    int GP;
    float GPA;
public:
    string name;
    string ID;
    string college;
    int age;
    int counum;
    char sex;//m or f (male,female)
    Course *c[100];

    Student()
    {
        GP=0;
        name="xiaomengxin";
        ID="000";
        age=0;
        sex='?';
        counum=0;
        college="***";
        GPA=0.0;
    }

    ~Student(){}

    void setGPA()
    {
        float sum=0,temp=0;
        for(int i=0;i<counum;i++)
        {
            if((*c[i]).jidian >= 1)
            {
                temp=(*c[i]).jidian * (*c[i]).point;
                sum+=temp;
            }
        }
        GPA=sum/GP;
    }

    float getGPA()
    {
        return GPA;
    }

    void setGP()
    {
        int sum=0;
        for(int i=0;i<counum;i++)
        {
            if((*c[i]).jidian >= 1)
            {
                sum+=(*c[i]).point;
            }
        }
        GP=sum;
    }

    int getGP()
    {
        return GP;
    }

    friend ostream& operator <<(ostream& out,Student& s1)
    {
        out<<"ID:"<<setw(3)<<s1.ID<<" name:"<<setw(5)<<s1.name<<" age: "<<setw(1)<<s1.age<<" sex: ";
        cout<<setw(1)<<s1.sex<<" college:"<<setw(5)<<s1.college<<endl;
        cout<<"Points you have learned:"<<s1.GP<<" GPA:"<<s1.GPA<<endl;
        return out;
    }
};
#endif // CLASSDEFINE_H_INCLUDED
