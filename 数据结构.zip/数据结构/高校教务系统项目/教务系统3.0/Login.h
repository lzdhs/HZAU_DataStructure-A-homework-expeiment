#ifndef LOGIN_H_INCLUDED
#define LOGIN_H_INCLUDED
#include <iostream>
#include "classdefine.h"
#include "LinkListdefine.h"

Student* searchstu1(stulist lst[],int num,string id)
{
    stunode *p;
    for(int i=0;i<num;i++)
    {
        for(p=lst[i];p!=NULL;p=p->next)
        {
            if(p->stu.ID==id)
            {
                return &(p->stu);
            }
        }
    }
    return &(p->stu);
}

Teacher* searchtea(tealist lst[],int num,string id)
{
    teanode *p;
    for(int i=0;i<num;i++)
    {
        for(p=lst[i];p!=NULL;p=p->next)
        {
            if(p->t.ID==id)
            {
                cout<<p->t;
                return &(p->t);
            }
        }
    }
    return NULL;
}

void switchmajor(stunode *p,stulist lst[],int num,string col,yearhashlist nianji[])
{
    int i;
    for(i=0;i<num;i++)
    {
        if(lst[i]->stu.college==col)
            break;
    }
    stunode *a=new stunode();
    *a=*p;
    a->stu.college=col;
    a->next=lst[i]->next->next;
    lst[i]->next=a;

    for(i=0;i<num;i++)
    {
        if(lst[i]->stu.college==p->stu.college)
            break;
    }
    delstu(lst[i],p->stu.ID,nianji);
}

void modifystu(stulist lst[],int num,string id,yearhashlist ye[])//except GP&GPA
{
    int choice;
    string name_,col;
    int age_;
    stunode *p=NULL;
    int year,coll,cla,n;
    Hash(id,year,coll,cla,n);
    if(searchstu(year,coll,cla,n,ye))
    {
         cout<<"Please choose which information you want to modify:"<<endl;
         cout<<"1.name"<<endl<<"2.age"<<endl<<"3.college(switch one 's major)"<<endl<<"Your choice:";
         cin>>choice;
         switch(choice)
         {
             case 1:cout<<"Please input his/her new name:";cin>>name_;p->stu.name=name_;break;
             case 2:cout<<"Please input his/her new age:";cin>>age_;p->stu.age=age_;break;
             case 3:cout<<"Please input his/her new college:";cin>>col;switchmajor(p,lst,num,col,ye);break;
         }
    }
    else
    {
        cout<<"This student does not exist!";
        getchar();
        return;
    }
}

void modifytea(tealist lst[],int num,string id)
{
    int choice;
    string name_,col;
    int age_;
    Teacher *p=searchtea(lst,num,id);
    if(p)
    {
         cout<<"Please choose which information you want to modify:"<<endl;
         cout<<"1.name"<<endl<<"2.age"<<endl<<"3.profession title"<<endl<<"Your choice:";
         cin>>choice;
         switch(choice)
         {
             case 1:cout<<"Please input his/her new name:";cin>>name_;p->name=name_;break;
             case 2:cout<<"Please input his/her new age:";cin>>age_;p->age=age_;break;
             case 3:cout<<"Please input his/her new profession title:";cin>>col;p->pfstitle=col;break;
         }
    }
    else
    {
        cout<<"This teacher does not exist!";
        getchar();
        return;
    }
}

#endif // LOGIN_H_INCLUDED
