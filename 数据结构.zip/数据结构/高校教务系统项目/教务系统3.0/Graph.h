#ifndef GRAPH_H_INCLUDED
#define GRAPH_H_INCLUDED
#include "TreeDefine.h"

typedef struct
{
    int num;
    Course *course;
}node;

typedef struct
{
    node mat[100][100];
    int vexnum;
}graph;

Course *cou[100];
node s[100],d[100],path[100];

graph makegraph(coutree root)
{
    coutree temp=root;
    show(root);
    int i,j,choice=1;
    coutree result;
    string id;
    graph g;
    for(i=0;i<100;i++)
    {
        for(j=0;j<100;j++)
            g.mat[i][j].num=32767;//�����ʼ��
    }
    g.vexnum=root->c.cnt;

    for(i=0;i<root->c.cnt;i++)
    {
        cout<<"\nPlease type the "<<i<<" course 's id:";
        cin>>id;
        result=searchcou(temp,id);//�ڽӾ���Ķ��㸳ֵ
        cou[i]=&(result->c);
    }

    for(i=0;i<g.vexnum;i++)
    {
        while(choice)
        {
            cout<<"Please enter the follow-up courses for "<<cou[i]->name<<", otherwise enter no:";
            cin>>id;
            if(id!="no")
            for(j=0;j<g.vexnum;j++)
            {
                if(cou[j]->ID==id)
                {
                    g.mat[i][j].num=cou[i]->point;//Ϊ�߸�Ȩֵ��ֵΪѧ��
                    break;
                }
            }
            cout<<"Are there any follow-up courses available?press 0 to create another or exit this program";
            cin>>choice;
        }
        choice=1;
    }
    cout<<"Create successfully!";
    getchar();
    return g;
}

void dijshortpath(graph &g)
{
    int i;

    for(i=0;i<g.vexnum;i++)
    {
        path[i].course=cou[i];
    }

    for(i=0;i<g.vexnum;i++)
    {
        s[i].num=0;
        d[i].num=g.mat[0][i].num;
        if(d[i].num<32767)
        {
            path[i].num=0;
        }
        else
        {
            path[i].num=-1;
        }
    }

    s[0].num=1;
    d[0].num=0;
    int min1,v;

    for(i=1;i<g.vexnum;i++)
    {
        min1=32767;
        for(int j=0;j<g.vexnum;j++)
        {
            if(!s[j].num && d[j].num<min1)
            {
                v=j;
                min1=d[j].num;
            }
        }
        s[v].num=1;
        for(int j=0;j<g.vexnum;j++)
        {
            if(!s[j].num && (d[v].num+g.mat[v][j].num<d[j].num))
            {
                d[j].num=d[v].num+g.mat[v][j].num;
                path[j].num=v;
            }
        }
    }
    int t;
    for(i=1;i<g.vexnum;i++)
    {
        t=path[i].num;
        cout<<"To learn "<<cou[i]->name<<" short path is:\n";
        while(t!=-1)
        {
            cout<<path[t].course->name<<endl;
            t=path[t].num;
        }
        cout<<"The short path 's score is:"<<d[i].num;
        cout<<endl;
    }
}

#endif // GRAPH_H_INCLUDED
