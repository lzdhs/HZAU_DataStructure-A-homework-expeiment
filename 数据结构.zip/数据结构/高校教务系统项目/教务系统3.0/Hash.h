#ifndef HASH_H_INCLUDED
#define HASH_H_INCLUDED
#include "classdefine.h"
#include "LinkListdefine.h"
#include <string>

//����ѧ�Ų�����ϣ����ѧ�����й����밴��ũ��ѧ�Ŵ���

typedef struct
{
    Student* p[31];
}classhashlist;//�༶��������ѧ��ָ��

typedef struct
{
    classhashlist cla[10];
}collegehashlist;//ѧԺ��һ��ѧԺĬ��10����

typedef struct
{
    collegehashlist y[18];
}yearhashlist;//�꼶��һ���꼶��17��ѧԺ

void inithashlist(yearhashlist ye[])
{
    int i,j,k,l;
    for(i=0;i<4;i++)
    {
        for(j=0;j<18;j++)
        {
            for(k=1;k<6;k++)
            {
                for(l=0;l<31;l++)
                {
                    ye[i].y[j].cla[k].p[l]=NULL;
                }
            }
        }
    }
}

void Hash(string s,int& year,int& col,int& cla,int& num)
{
    string y,coll,clas,n;
    y=s.substr(0,4);
    coll=s.substr(4,3);
    clas=s.substr(7,4);
    n=s.substr(11,2);
    year=stoi(y);
    col=stoi(coll);
    cla=stoi(clas);
    num=stoi(n);
}

int searchstudent(int yno,int colno,int clano,int num,yearhashlist ye[])
{
    if(num>=0 && num<=30 && ye[yno].y[colno].cla[clano].p[num]!=NULL)
    {
        cout<<*(ye[yno].y[colno].cla[clano].p[num]);
        return 1;
    }
    else
        return 0;
}

int searchclass(int yno,int colno,int cla,int num,yearhashlist y[])
{
    return searchstudent(yno,colno,cla%10,num,y);
}

int searchcollege(int yno,int college,int cla,int num,yearhashlist y[])
{
    if(college<=317 && college>300)
        return searchclass(yno,college-300,cla,num,y);
    else
        return 0;
}

int searchstu(int y,int college,int cla,int num,yearhashlist ye[])
{
    if(y-2023>=0 && y-2023<=3)
        return searchcollege(y-2023,college,cla,num,ye);
    else
        return 0;
}

void deletestuhashlist(int y,int college,int cla,int num,yearhashlist ye[])
{
    if(searchstu(y,college,cla,num,ye))
    {
        ye[y].y[college].cla[cla].p[num]=NULL;
    }
}
void hashlistcreate(string id,yearhashlist ye[],Student *ps)
{
    int year,college,clas,num;
    Hash(id,year,college,clas,num);
    ye[year-2023].y[college-300].cla[clas%10].p[num]=ps;
}
#endif // HASH_H_INCLUDED
