#ifndef TREEDEFINE_H_INCLUDED
#define TREEDEFINE_H_INCLUDED
#include "classdefine.h"
#include <string>
#include <stack>

typedef struct counode
{
    Course c;
    counode *lchild,*rchild;
}counode,*coutree;

void insertbst(coutree &root,Course cou)
{
    coutree s;
    if(!root)
    {
        s->c.cnt++;
        s=new counode;
        s->c=cou;
        s->lchild=s->rchild=NULL;
        root=s;
    }
    else if(cou.ID < root->c.ID)
        insertbst(root->lchild,cou);
    else if(cou.ID > root->c.ID)
        insertbst(root->rchild,cou);
}

void createcoutree(coutree &root)
{
    Course temp;
    root=NULL;
    string id,name;
    int p;
    system("cls");
    cout<<"\nNote: After creation, ";
    cout<<"the courses will be automatically sorted in ascending order by course number";
    flag:
    cout<<"\nPlease type the course id:";
    cin>>id;
    cout<<"\nPlease type the course name:";
    cin>>name;
    cout<<"\nPlease type the course's point:";
    cin>>p;
    temp=Course(name,id,p);
    char choice='y';
    while(1)
    {
        insertbst(root,temp);
        cout<<"Created successfully! Do you want to add another?(y/n)";
        cin>>choice;
        if(choice == 'y')
            goto flag;
        else
            break;
    }
}

coutree searchcou(coutree root,string c)
{
    if(!root)return NULL;
    else if(root->c.ID == c)
        {
            return root;
        }
    else if(root->c.ID > c)
        return searchcou(root->lchild,c);
    else
        return searchcou(root->rchild,c);
}

coutree delcou(coutree &root,string id)
{
    counode *p,*f,*s,*q;
    p=root;
    f=NULL;
    while(p)
    {
        if(p->c.ID == id)
            break;
        f=p;
        if(p->c.ID > id)
            p=p->lchild;
        else
            p=p->rchild;
    }
    if(p==NULL)
    {
        cout<<"No ID for this course!Delete failed!Press any key to go back";
        getchar();
        return root;
    }
    if(p->lchild == NULL)
    {
        if(f == NULL)
            root=p->rchild;
        else if(f->lchild == p)
            f->lchild=p->rchild;
        else
            f->rchild=p->rchild;
        p->c.cnt--;
        free(p);//?
    }
    else
    {
        q=p;
        s=p->lchild;
        while(s->rchild)
        {
            q=s;
            s=s->rchild;
        }
        if(q == p)
            q->lchild=s->lchild;
        else
            q->rchild=s->lchild;
        p->c=s->c;
        p->c.cnt--;
        free(s);
    }
    cout<<"Delete successfully!Press any key to continue";
    getchar();
    return root;
}

void modifycou(coutree &cou)
{
    system("cls");
    cout<<"Please enter the ID of the course you want to modify ��";
    string id,name;
    int point,stucount;
    cin>>id;
    counode *p=searchcou(cou,id);
    cout<<"Please choose which you want to modify?";
    cout<<"\n1.course name\n2.point\n3.stucount\n4.teacher(this part hasn't been finished)\n";
    int choice;
    cin>>choice;
    switch(choice)
    {
        case 1:
            {
                cout<<"Please type the new name of the course:";
                cin>>name;
                p->c.name=name;
                cout<<"Modified successfully!Press any key to continue";
                getchar();
                return;
            }
        case 2:
            {
                cout<<"Please type the new point of the course:";
                cin>>point;
                p->c.point=point;
                cout<<"Modified successfully!Press any key to continue";
                getchar();
                return;
            }
        case 3:
            {
                cout<<"Please type the new student count of the course:";
                cin>>stucount;
                p->c.stucount=stucount;
                cout<<"Modified successfully!Press any key to continue";
                getchar();
                return;
            }
        default:{cout<<"Wrong choice!Press any key to continue";getchar();return;}

    }
}

void show(coutree root)
{
    if(root)
    {
        show(root->lchild);
        cout<<root->c;
        show(root->rchild);
    }
}

#endif // TREEDEFINE_H_INCLUDED
