#include <iostream>
//#include "classdefine.h"//����ѧ������ʦ���γ���Ķ���
//#include "LinkListdefine.h"//����ѧ������ʦ�ڵ㡢����������ز���������ɾ����ʵ��
#include "Login.h"//����ѧ������ʦ����������ʵ�֣���ͷ�ļ�����������¼��
#include "TreeDefine.h"//�����γ����Ķ��弰����ز���
//#include "Hash.h"
#include "ChooseCourse.h"
#include "Graph.h"
using namespace std;

stulist liststu[18];//ѧ����������
tealist listtea[18];

yearhashlist nianji[4];

int main()
{
    coutree treecou=NULL;
    string account,col,id;
    graph g;
    int choice=1,stulistnum=0,tealistnum=0,i,tag;//stulistnum,tealistnum�������������ı���

    flag:
        system("cls");
    cout<<"Please type the account:";//�����˺�
    cin>>account;
    stunode *s;
    teanode *t_;
    if(!account.find_first_of("0"))//�ǹ���Ա
    {
        while(choice)
        {
            system("cls");
            cout<<"Please choose the functions you want to do:";
            cout<<"\n1 Create\n2 Add\n3 Delete\n4 Search\n5 Modify\n6 Show\n7 Develop talent training programs\nYour choice:";
            cin>>choice;
            switch(choice)
            {
                case 1://create    outer
                {
                system("cls");
                cout<<"Please decide which type you want to create?"<<endl;
                cout<<"1 Students"<<endl<<"2 Teachers"<<endl<<"3 Courses"<<endl;
                cin>>choice;

                switch(choice)
                {
                    case 1://create student   1.1
                    {
                        inithashlist(nianji);
                        liststu[stulistnum]=new stunode;
                        initstu(&liststu[stulistnum]);
                        createstu(liststu[stulistnum],nianji);
                        stulistnum++;
                        break;
                    }
                    case 2://create teacher    `1.2
                    {
                        listtea[tealistnum]=new teanode;
                        inittea(&listtea[tealistnum]);
                        createtea(listtea[tealistnum]);
                        tealistnum++;
                        break;
                    }
                    case 3://1.3create course
                    {
                        createcoutree(treecou);
                        if(treecou)
                        getchar();
                        break;
                    }
                }//end of switch
                break;//case o1 's break
                }//end of case o1
                    case 2://add     outer
                        {
                            cout<<"Please decide which people you want to add?";
                            cout<<endl<<"1 Students"<<endl<<"2 Teachers"<<endl<<"3 Courses"<<endl;
                            cin>>choice;
                            switch(choice)
                            {
                            case 1://add stu    2.1
                                {
                                    cout<<"Please input the student 's college:";
                                    cin>>col;
                                    tag=1;
                                    for(i=0;i<stulistnum;i++)
                                    {
                                        if(liststu[i]->stu.college==col)
                                        {
                                            tag=0;//new
                                            break;
                                        }
                                    }
                                    if(tag)
                                    {
                                        cout<<"This college does not exist,Please create first!";
                                        break;
                                    }
                                    addstu(liststu[i],nianji);
                                    break;
                                }

                            case 2://add tea 2.2
                                {
                                    cout<<"Please input the teacher 's college:";
                                    cin>>col;
                                    tag=1;
                                    for(i=0;i<tealistnum;i++)
                                    {
                                        if(listtea[i]->t.college==col)
                                        {
                                            tag=1;
                                            break;
                                        }
                                    }
                                    if(tag)
                                    {
                                        cout<<"This college does not exist,Please create first!";
                                        break;
                                    }
                                    addtea(listtea[i]);
                                    break;
                                }

                            case 3://2.3
                                {
                                    system("cls");
                                    string name;int p;Course temp;
                                    cout<<"Note: After creation, the courses will be automatically sorted";
                                    cout<<" in ascending order by course number";
                                    cout<<"Please type the course id:";
                                    cin>>id;
                                    cout<<"\nPlease type the course name:";
                                    cin>>name;
                                    cout<<"\nPlease type the course's point:";
                                    cin>>p;
                                    temp=Course(name,id,p);
                                    insertbst(treecou,temp);
                                    break;
                                }
                            }
                            break;//case o2 's break
                        }
                    case 3://delete  outer
                        {
                            cout<<"Please decide which  kind of people you want to delete";
                            cout<<endl<<"1 Students"<<endl<<"2 Teachers"<<endl<<"3 Courses"<<endl;
                            cin>>choice;
                            switch(choice)
                            {
                            case 1://delstu 3.1
                                {
                                    cout<<"Please input the student 's college:";
                                    cin>>col;
                                    tag=1;
                                    for(i=0;i<stulistnum;i++)
                                    {
                                        if(liststu[i]->stu.college==col)
                                        {
                                            tag=0;
                                            break;
                                        }
                                    }
                                    if(tag)
                                    {
                                        cout<<"This college does not exist,Please create first!";
                                        break;
                                    }
                                    cout<<"Please input the student 's id:";
                                    cin>>id;
                                    delstu(liststu[i],id,nianji);
                                    break;
                                }
                            case 2://3.2del tea
                                {
                                    cout<<"Please input the teacher 's college:";
                                    cin>>col;
                                    tag=0;
                                    for(i=0;i<tealistnum;i++)
                                    {
                                        if(listtea[i]->t.college==col)
                                        {
                                            tag=1;
                                            break;
                                        }
                                    }
                                    if(tag)
                                    {
                                        cout<<"This college does not exist,Please create first!";
                                        break;
                                    }
                                    cout<<"Please input the teacher 's id:";
                                    cin>>id;
                                    deltea(listtea[i],id);
                                    break;
                                }
                            case 3://3.3del cou
                                {
                                    cout<<"Please input the course id:";
                                    cin>>id;
                                    treecou=delcou(treecou,id);
                                    break;
                                }
                            }//end of switch
                            break;//case o3's break
                        }//end of case o3
                            case 4://search    outer
                                {
                                    cout<<"Please decide which kind of people you want to search"<<endl;
                                    cout<<"1 Students"<<endl<<"2 Teachers"<<endl<<"3 Courses"<<endl;
                                    cin>>choice;
                                    switch(choice)
                                    {
                                    case 1://4.1search student
                                        {
                                            cout<<"Please input the student 's id:";
                                            cin>>id;
                                            int year,college,cla,num;
                                            Hash(id,year,college,cla,num);
                                            if(!searchstu(year,college,cla,num,nianji))
                                                cout<<"No person for this id!"<<endl;
                                            break;
                                        }
                                    case 2://4.2search teacher
                                        {
                                            cout<<"Please input the teacher 's id:";
                                            cin>>id;
                                            if(!searchtea(listtea,tealistnum,id))
                                                cout<<"No person for this id!"<<endl;
                                            break;
                                        }
                                    case 3://4.3search course
                                        {
                                            cout<<"Please input the course 's id:";
                                            cin>>id;
                                            if(!searchcou(treecou,id))
                                                cout<<"No course for this id!"<<endl;
                                            else
                                            {
                                                coutree c=searchcou(treecou,id);
                                                cout<<c->c;
                                            }
                                            break;
                                        }
                                    }//end of switch
                                    break;//case o4 's break
                                }//end of case o4
                            case 5://modify    outer
                                {
                                    cout<<"Please decide which kind of people you want to modify"<<endl;
                                    cout<<"1 Students"<<endl<<"2 Teachers"<<endl<<"3 Courses"<<endl;
                                    cin>>choice;
                                    switch(choice)
                                    {
                                        case 1:{
                                            cout<<"Please input the student 's id:";cin>>id;modifystu(liststu,stulistnum,id,nianji);break;
                                        }
                                        case 2:cout<<"Please input the teacher 's id:";cin>>id;modifytea(listtea,tealistnum,id);break;
                                        case 3:cout<<"Please input the course 's id:";cin>>id;modifycou(treecou);break;
                                    }
                                }
                            case 6://show outer
                                {
                                    cout<<"Please decide which kind of people you want to show?"<<endl;
                                    cout<<"1 Students"<<endl<<"2 Teachers"<<endl<<"3 Courses"<<endl;
                                    cin>>choice;
                                    switch(choice)
                                    {
                                        case 1:{
                                            cout<<"Please type the college 's student you want to show?\n";
                                            cin>>col;
                                            for(i=0;i<18;i++)
                                            {
                                                if(liststu[i]->stu.college==col)
                                                    break;
                                            }
                                            s=liststu[i]->next;
                                            cout<<"College:"<<col<<endl;
                                            do
                                            {
                                                cout<<s->stu;
                                                s=s->next;
                                            }while(s);
                                            cout<<"Press any key to continue";
                                            getchar();
                                            break;
                                        }
                                        case 2:{
                                            cout<<"Please type the college 's teacher you want to show?\n";
                                            cin>>col;
                                            for(i=0;i<18;i++)
                                            {
                                                if(listtea[i]->t.college==col)
                                                    break;
                                            }
                                            t_=listtea[i]->next;
                                            cout<<"College:"<<col<<endl;
                                            do
                                            {
                                                cout<<t_->t;
                                                t_=t_->next;
                                            }while(t_);
                                            cout<<"Press any key to continue";
                                            getchar();
                                            break;
                                        }
                                        case 3:
                                            {
                                                if(treecou)
                                                    show(treecou);
                                                else
                                                    cout<<"No course has been added!Please create first!";
                                                getchar();
                                                break;
                                            }

                                    }
                                }
                            case 7:
                                {
                                    g=makegraph(treecou);
                                    break;
                                }
                            default:cout<<"Wrong choice!";break;




        }//end of switch(biggest)
            cout<<"\nDo you want to exit?Press 0 to end this program,press 1 to continue,Press 4 to exit to menu.";
            cin>>choice;
            if(choice==4)goto flag;
        }//end of while
    }//end of if(guaanliyuan)



    else if(!account.find_first_of("1"))//����ʦ
    {
        flag1:
            //Ϊ�˼�����ʦ�ĸ�����ÿ����ʦֻ����һ�ſγ̣�ÿ���γ�֮��һ����ʦ����
        Teacher *t=NULL;
        t=searchtea(listtea,18,account);
        if(!t)
        {
            cout<<"Wrong id\nPress any key to continue";
            getchar();
            goto flag;
        }
        system("cls");
        cout<<"Please choose which function you want to do?"<<endl;
        cout<<"1 Choose course\n2 Show course information\n3 Delete course\n4 Give score to studentsYour choice:"<<endl;
        cin>>choice;
        switch(choice)
        {
        case 1:
            {
                teachoosecou(*t,treecou);
                break;
            }
        case 2:
            {
                showcoustuinfo(*(t->teach));
                break;
            }
        case 3:
            {
                delteacou(*t);
                break;
            }
        case 4:
            {
                givescore(*t);
                break;
            }
        }
        cout<<"\nDo you want to exit?Press 0 to end this program,press 1 to continue,Press 4 to exit to menu.";
        cin>>choice;
        if(choice==4)goto flag;
        if(choice==1)goto flag1;
    }



    else//��ѧ��
    {
        int year,coll,clas,num;
        Hash(account,year,coll,clas,num);
        flag2:

        if(searchstu(year,coll,clas,num,nianji))
        {
            system("cls");
            cout<<"Please choose which function you want to do?"<<endl;
            cout<<"1 Choose course\n2 Show course\n3 Delete course\n4 Search training programYour choice:"<<endl;
            cin>>choice;
            Student *s=searchstu1(liststu,18,account);
            switch(choice)
            {
            case 1:
                {
                    stuchoosecou(treecou,*s);
                    break;
                }
            case 2:
                {
                    cout<<"These are the courses which you have chosen:\n";
                    showstucourse(*s);
                    break;
                }
            case 3:
                {
                    delstucou(*s);
                    break;
                }
            case 4:
                {
                    dijshortpath(g);
                    break;
                }
            }
            cout<<"\nDo you want to exit?Press 0 to end this program,press 1 to continue,Press 4 to exit to menu.";
            cin>>choice;
            if(choice==4)goto flag;
            if(choice==1)goto flag2;
        }
        else
        {
            cout<<"Wrong id!\nPress any key to continue."<<endl;
            getchar();
            goto flag;
        }
    }
    system("cls");
    cout<<"Thanks for using this system"<<endl;
    cout<<"Our group members are:wnx,zyy,nxy";
    return 0;
}
/*
����Ļ����߼�
1.0�棺
�����ɵ�¼ҳ�棬��ʱ��û���κ���ʦ��ѧ����ֻ�й���Ա��û�й���Ա�ࣩ
�����˺ż��ɵ�¼
�˺�0��ͷΪ����Ա��1Ϊ��ʦ��2ѧ������ʱֻ������0��ͷ���˺ţ�
�������Աϵͳ������Ա��������ѧ������ʦ

2.0
�γ�������ɾ�Ĳ飬ͨ������������ʵ��
�γ�������һ�ã�ȫУ�ģ���ʦ��ѧ�������ж�����ֲ�ͬѧԺ
����ѧ��ѧ�Ų����˹�ϣ��������������д��

3.0
��ǿ�˳����³����,case2.1
ѡ�ι��ܣ�ѧ���γ���Ķ�����ʹ����˳���
�˿ι��ܣ�˳�����ɾ��
��ʦ��ѡ���˿Σ�1��1��
���ֹ��ܣ������㣬����1��ѧ��ѧ�����ӣ�
���򣺿�����������ģ��
*/
