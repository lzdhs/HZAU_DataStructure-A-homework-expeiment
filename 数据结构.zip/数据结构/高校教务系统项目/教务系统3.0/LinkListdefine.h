#ifndef LINKLISTDEFINE_H_INCLUDED
#define LINKLISTDEFINE_H_INCLUDED

#include "classdefine.h"
#include "Hash.h"
#include <string>
#include <iostream>

typedef struct stunode
{
    Student stu;
    stunode* next;
}stunode,*stulist;

typedef struct teanode
{
    Teacher t;
    teanode* next;
}teanode,*tealist;


void initstu(stulist *a)
{
    (*a)->next=NULL;
    cout<<"Please type the student 's college:"<<endl;
    cin>>(**a).stu.college;
}

void inittea(tealist *a)
{
    (*a)->next=NULL;
    cout<<"Please type the teacher 's college:"<<endl;
    cin>>(**a).t.college;
}

void createstu(stulist s,yearhashlist nianji[])
{
    stunode *r,*p;
    char choice='y';
    r=s;

    while(choice=='y')
    {
        p=new stunode();
        cout<<"Please type student 's name:";
        cin>>p->stu.name;
        cout<<"Please type student 's ID:";
        flag:
        cin>>p->stu.ID;
        if(((p->stu.ID).size())!=13)
        {
            cout<<"\ntype error!Please type again!\n";
            goto flag;
        }
        cout<<"Please type student 's age:";
        cin>>p->stu.age;
        cout<<"Please type student 's sex:";
        cin>>p->stu.sex;
        p->stu.college=(*s).stu.college;

        r->next=p;
        r=p;
        hashlistcreate(p->stu.ID,nianji,&(p->stu));
        cout<<"Added!Continue?(y/n):";
        cin>>choice;
    }
    r->next=NULL;
}

void createtea(tealist tea)
{
    teanode *r,*s;
    char choice='y';
    r=tea;

    while(choice=='y')
    {
        s=new teanode();
        cout<<"Please type teacher 's name:";
        cin>>s->t.name;
        cout<<"Please type teacher 's ID:";
        cin>>s->t.ID;
        cout<<"Please type teacher 's age:";
        cin>>s->t.age;
        cout<<"Please type teacher 's sex:";
        cin>>s->t.sex;
        cout<<"Please type teacher 's Professional title:";
        cin>>s->t.pfstitle;
        s->t.college=(*tea).t.college;

        r->next=s;
        r=s;
        cout<<"Added!Continue?(y/n):";
        cin>>choice;
    }
    r->next=NULL;
}

void addstu(stulist s,yearhashlist nianji[])
{
    stunode *st=new stunode();
    st->next=s->next;
    s->next=st;
    st->stu.college=s->stu.college;

    cout<<"Please type student 's name:";
    cin>>st->stu.name;
    cout<<"Please type student 's ID:";
    cin>>st->stu.ID;
    cout<<"Please type student 's age:";
    cin>>st->stu.age;
    cout<<"Please type student 's sex";
    cin>>st->stu.sex;
    hashlistcreate(st->stu.ID,nianji,&(st->stu));
    cout<<"Added!Press any key to continue\n";
    getchar();
}

void addtea(tealist tea)
{
    teanode *te=new teanode();
    te->next=tea->next;
    tea->next=te;
    te->t.college=tea->t.college;

    cout<<"Please type teacher 's name:";
    cin>>te->t.name;
    cout<<"Please type teacher 's ID:";
    cin>>te->t.ID;
    cout<<"Please type teacher 's age:";
    cin>>te->t.age;
    cout<<"Please type teacher 's sex:";
    cin>>te->t.sex;
    cout<<"Please type teacher 's Professional title:";
    cin>>te->t.pfstitle;
    cout<<"Please type teacher 's college:";
    cin>>te->t.college;
    cout<<"Added!Press any key to continue";
    getchar();
}


void delstu(stulist a,string id,yearhashlist ye[])
{
    stunode *p=a,*q=a->next;
    int year,college,cla,num;
    Hash(id,year,college,cla,num);
    for(;q!=NULL;p=p->next,q=q->next)
    {
        if(q->stu.ID==id)
        {
            p->next=q->next;

            deletestuhashlist(year,college,cla,num,ye);
            delete(q);
            return;
        }
    }
    cout<<"No person in this ID!Delete failed!\n";
}

void deltea(tealist a,string id)
{
    teanode *p=a,*q=a->next;
    for(;q!=NULL;p=p->next,q=q->next)
    {
        if(q->t.ID==id)
        {
            p->next=q->next;
            delete(q);
            return;
        }
    }
    cout<<"No person in this ID!\n";
}

void inittealist(tealist tea[])
{
    for(int i=0;i<18;i++)
    {
        tea[i]->next=NULL;
        tea[i]=new teanode;
    }
}
#endif // LINKLISTDEFINE_H_INCLUDED
