#ifndef CHOOSECOURSE_H_INCLUDED
#define CHOOSECOURSE_H_INCLUDED
#include "TreeDefine.h"

void stuchoosecou(coutree &root,Student &s)
{
    cout<<"Courses:\n";
    show(root);
    string id;
    cout<<"Please enter the course id you want to select:";
    cin>>id;
    counode *co=searchcou(root,id);
    co->c.s[co->c.stucount++]=&s;
    s.c[s.counum++]=&(co->c);
    cout<<"Choose successfully!";
}

template <typename t>
int qkpass(t course[],int low,int high)
{
    t temp=course[low];
    while(low<high)
    {
        while(low<high && course[high]->ID>=temp->ID)
            high--;
        if(low<high)
        {
            course[low]=course[high];
            low++;
        }

        while(low<high && course[low]->ID<temp->ID)
            low++;
        if(low<high)
        {
            course[high]=course[low];
            high--;
        }
    }
    course[low]=temp;
    return low;
}
template <typename t>
void qksort(t course[],int low,int high)
{
    int pos;
    if(low<high)
    {
        pos=qkpass(course,low,high);
        qksort(course,low,pos-1);
        qksort(course,pos+1,high);
    }
}

void showstucourse(Student &s)
{
    qksort(s.c,0,s.counum-1);
    for(int i=0;i<s.counum;i++)
    {
        cout<<*(s.c[i]);
        cout<<"The score is:"<<s.c[i]->jidian<<endl;
    }
}

void delstucou(Student &s)
{
    string id;
    int flag=1,i;
    showstucourse(s);
    cout<<"Please enter the course id you want to delete:";
    cin>>id;
    for(i=0;i<s.counum;i++)
    {
        if(id == s.c[i]->ID)
        {
            flag=0;
        }
    }
    if(flag)
    {
        cout<<"Wrong id!";
        return;
    }
    else
    {
        for(int j=i;j<s.counum-1;j++)
        {
            s.c[j]=s.c[j+1];
        }
        s.counum--;
        cout<<"Deleted successfully!";
    }
}

void teachoosecou(Teacher &t,coutree &root)
{
    cout<<"Course:\n";
    show(root);
    string id;
    cout<<"Please enter the course id you want to select:";
    cin>>id;
    counode *co=searchcou(root,id);
    co->c.t=&t;
    t.teach=&(co->c);
    cout<<"Choose successfully!";
}

void delteacou(Teacher &t)
{
    t.teach->t=NULL;
    t.teach=NULL;
    cout<<"Deleted successfully!";
}

void showcoustuinfo(Course &c)
{
    qksort(c.s,0,c.stucount-1);
    int i;
    for(i=0;i<c.stucount;i++)
    {
        cout<<*(c.s[i]);
    }
}

void givescore(Teacher &t)
{
    int num=t.teach->stucount;
    float score;
    int i,j;
    for(i=0;i<num;i++)
    {
        cout<<*(t.teach->s[i]);
        cout<<"Please give the score to this student:";
        cin>>score;
        for(j=0;j<t.teach->s[i]->counum;j++)//��ʦ�������ſεĸ�ѧ���Ŀγ̵ļ���
        {
            if(t.teach->s[i]->c[j]->ID == t.teach->ID)
            {
                break;
            }
        }
        t.teach->s[i]->c[j]->jidian=score;
        t.teach->s[i]->setGP();
        t.teach->s[i]->setGPA();
    }
    cout<<"Give successfully!";
}
#endif // CHOOSECOURSE_H_INCLUDED
