#include <iostream>

using namespace std;

typedef struct
{
    int i,j,num;
}node;

typedef struct
{
    node data[100];
    int m,n,len;
}juzhen;

int main()
{
    int cntA,cntB,i,j,m;
    cin>>cntA>>cntB;
    int cnt=cntB;
    juzhen a,b;

    for(i=0;i<cntA;i++)
    {
        cin>>a.data[i].i>>a.data[i].j>>a.data[i].num;
    }
    for(j=0;j<cntB;j++)
    {
        cin>>b.data[j].i>>b.data[j].j>>b.data[j].num;
    }
    int flag=1;
    for(i=0;i<cntA;i++)
    {
        flag=1;
        for(j=0;j<cntB;j++)
        {
            if(a.data[i].i==b.data[j].i&&a.data[i].j==b.data[j].j)
            {
                b.data[j].num+=a.data[i].num;
                //cout<<b.data[j].num<<endl;
                flag=0;
                break;
            }
        }
        if(flag)
        {
            b.data[cnt++]=a.data[i];
        }
    }
    node temp;
    for(i=0;i<cnt;i++)
    {
        for(j=i+1;j<cnt;j++)
        {
            if(b.data[i].i>b.data[j].i)
            {
                temp=b.data[i];
                b.data[i]=b.data[j];
                b.data[j]=temp;
            }
            else if(b.data[i].i==b.data[j].i)
            {
                m=i+1;
                    if(b.data[i].j>b.data[m].j)
                    {
                        temp=b.data[m];
                        b.data[m]=b.data[i];
                        b.data[i]=temp;
                    }
            }

        }
    }
    flag=1;
    for(i=0;i<cnt;i++)
    {
        if(b.data[i].num==0)
            continue;
        cout<<b.data[i].i<<" "<<b.data[i].j<<" "<<b.data[i].num<<endl;
        flag=0;
    }
    if(flag)
        cout<<"-1 -1 -1";
    return 0;
}
