#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    char data;
    struct node *lchild;
    struct node *rchild;
}node,*tree;

void createtree(tree *bt)
{
    char ch;
    ch=getchar();
    if(ch=='#')
        *bt=NULL;
    else
    {
        *bt=(tree)malloc(sizeof(node));
        (*bt)->data=ch;
        createtree(&((*bt)->lchild));
        createtree(&((*bt)->rchild));
    }
}

void preorder(tree root)//digui
{
    if(root!=NULL)
    {
        printf("%c ",root->data);
        preorder(root->lchild);
        preorder(root->rchild);
    }
}

void midorder(tree root)//digui
{
    if(root!=NULL)
    {
        midorder(root->lchild);
        printf("%c ",root->data);
        midorder(root->rchild);
    }
}

void postorder(tree root)//digui
{
    if(root!=NULL)
    {
        postorder(root->lchild);
        postorder(root->rchild);
        printf("%c ",root->data);
    }
}

typedef struct
{
    tree arr[50];
    int top;
}stack;

void init(stack *s)
{
    s->top=-1;
}

void push(stack *s,tree ch)
{
    s->top++;
    s->arr[s->top]=ch;
}

tree pop(stack *s)
{
    tree c=s->arr[s->top];
    s->top--;
    return c;
}

void pre(tree root)
{
    stack s;
    init(&s);
    node *p;
    p=root;
    while(p||(s.top!=-1))
    {
        if(p)
        {
            printf("%c ",p->data);
            push(&s,p);
            p=p->lchild;
        }
        else
        {
            p=pop(&s);
            p=p->rchild;
        }
    }
}

void mid(tree root)
{
    stack s;
    init(&s);
    tree p=root;
    while(p||(s.top!=-1))
    {
        if(p)
        {
            push(&s,p);
            p=p->lchild;
        }
        else
        {
            p=pop(&s);
            printf("%c ",p->data);
            p=p->rchild;
        }
    }
}

void post(tree root)
{
    node *p,*q;
    stack s;
    q=NULL;
    p=root;
    init(&s);
    while(p||(s.top!=-1))
    {
        if(p)
        {
            push(&s,p);
            p=p->lchild;
        }
        else
        {
            p=s.arr[s.top];
            if(p->rchild==NULL||p->rchild==q)
            {
                printf("%c ",p->data);
                q=p;
                p=pop(&s);
                p=NULL;
            }
            else
            {
                p=p->rchild;
            }
        }
    }
}
int main()
{
    tree t;
    createtree(&t);
    preorder(t);
    printf("\n");
    midorder(t);
    printf("\n");
    postorder(t);
    printf("\n");
    pre(t);
    printf("\n");
    mid(t);
    printf("\n");
    post(t);
    return 0;
}
