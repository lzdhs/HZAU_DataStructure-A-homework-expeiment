#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct tnode
{
    int data;
    int dep;
    struct tnode *lchild;
    struct tnode *rchild;
}tnode,*tree;

typedef struct
{
    tree arr[100];
    int top;
}stack;

typedef struct qnode
{
    tree data;
    struct qnode *next;
}qnode;

typedef struct
{
    qnode* front;
    qnode* rear;
}quene;

void initquene(quene *q)
{
    q->front=q->rear=(qnode*)malloc(sizeof(qnode));
    q->front->next=NULL;
}

void enter(quene *q,tree e)
{
    qnode *p=(qnode*)malloc(sizeof(qnode));
    p->data=e;
    p->next=NULL;
    q->rear->next=p;
    q->rear=p;
}

void del(quene *q,tree *e)
{
    qnode* p=q->front->next;
    *e=p->data;
    q->front->next=p->next;
    if(q->rear==p)q->rear=q->front;
    free(p);
}

void initstack(stack *s)
{
    s->top=-1;
}

void push(stack *s,tree root)
{
    s->arr[++s->top]=root;
}

tree pop(stack *s)
{
    tree t=s->arr[s->top--];
    return t;
}

tree gettop(stack *s)
{
    tree t=s->arr[s->top];
    return t;
}

void createtnode(tree *t,int n,int depth)
{
    *t=(tnode*)malloc(sizeof(tnode));
    (*t)->data=n;
    (*t)->dep=depth;
    (*t)->lchild=NULL;
    (*t)->rchild=NULL;
}

int wnx(char ch)
{
    if(ch=='('||ch==')'||ch==',')
    {
        return 1;
    }
    else
        return 0;
}

void createtree(tree* root,char *s)
{
    int num,i=1,depth=1;
    stack a;
    initstack(&a);
    num=s[0]-'0';
    createtnode(&(*root),num,depth);
    tree p=*root,q=NULL;
    char ch;
    for(i=1;i<strlen(s)-1;i++)
    {
        if((wnx(s[i])==0)&&(wnx(s[i+1])==1))
        {
            num=s[i]-'0';
        }

        if(wnx(s[i])==1)
        {
            ch=s[i];
            if(ch=='('||ch==',')
                continue;
        }

        if((wnx(s[i])==0)&&(wnx(s[i+1])==0))
        {
            num=(s[i]-'0')*10+(s[i+1]-'0');
            i++;
        }

        if(ch=='(')
        {
            depth++;
            createtnode(&(p->lchild),num,depth);
            q=gettop(&a);
            if(q!=p)
                push(&a,p);
            p=p->lchild;
        }
        else if(ch==')')
        {
            p=pop(&a);
            depth--;
        }
        else if(ch==',')
        {
            p=pop(&a);
            createtnode(&(p->rchild),num,depth);
            push(&a,p->rchild);
            p=p->rchild;
        }
        else
            break;
    }
}

void bl(tree *root)
{
    quene q;
    initquene(&q);
    tree t[100];
    enter(&q,*root);
    int i=0;
    while(q.front!=q.rear)
    {
        //printf("%d ",q.front->data->data);
        if(q.front->next->data->rchild!=NULL)
        {
            enter(&q,q.front->next->data->rchild);
        }
        if(q.front->next->data->lchild!=NULL)
        {
            enter(&q,q.front->next->data->lchild);
        }
        del(&q,&t[i]);
        i++;
    }
    int j=t[i-1]->dep,k;
    for(k=i-1;k>=0;k--)
    {
        if(j!=t[k]->dep)
            printf("\n");
        printf("%d ",t[k]->data);
        j=t[k]->dep;
    }
}

void pre(tree root)
{
    if(root)
    {
        printf("%d ",root->data);
        pre(root->lchild);
        pre(root->rchild);
    }
}
int main()
{
    tree t=NULL;
    char s[100];
    gets(s);
    createtree(&t,s);
    //pre(t);
    bl(&t);
    return 0;
}
