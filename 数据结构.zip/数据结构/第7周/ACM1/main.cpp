#include <iostream>

using namespace std;

int main()
{
    long long int light,people,dist,yz=1;
    cin>>light>>people>>dist;
    while(1)
    {
        if((light/people)==((yz+dist)/yz))
        {
            cout<<yz;
            break;
        }
        yz++;
    }
    return 0;
}
//light/people=yz+dist/yz
