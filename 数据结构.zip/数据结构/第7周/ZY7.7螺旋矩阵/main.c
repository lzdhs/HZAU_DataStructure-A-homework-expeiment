#include <iostream>
#pragma GCC optimize(2)
using namespace std;

int main()
{
    int a[100][100],n;
    cin>>n;
    int i,j,k=1;
    for(i=0;i<100;i++)
    {
        for(j=0;j<100;j++)
            a[i][j]=0;
    }
    i=1;j=1;
    int dir=1;
    while(1)
    {
        while(dir==1)
        {
            a[i][j]=k;
            j++;
            k++;
            if(a[i][j]!=0||j>n)
            {
                j--;
                i++;
                dir=2;
            }
        }
        if(k>n*n)break;
        while(dir==2)
        {
            a[i][j]=k;
            i++;
            k++;
            if(a[i][j]!=0||i>n)
            {
                i--;
                j--;
                dir=3;
            }
        }
        if(k>n*n)break;
        while(dir==3)
        {if(k>n*n)break;
            a[i][j]=k;
            j--;
            k++;
            if(a[i][j]!=0||j<1)
            {
                j++;
                i--;
                dir=4;
            }
        }
        if(k>n*n)break;
        while(dir==4)
        {
            a[i][j]=k;
            i--;
            k++;
            if(a[i][j]!=0||i<1)
            {
                i++;
                j++;
                dir=1;
            }
        }
        if(k>n*n)break;
    }
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            cout<<a[i][j]<<" ";
        }
        cout<<endl;
    }
    return 0;
}


