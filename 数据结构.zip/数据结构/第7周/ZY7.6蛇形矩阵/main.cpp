1#include <iostream>

using namespace std;

int main()
{
    int a[100][100];
    int i=1,j=1,n,k,dir=1;
    cin>>n;
    a[1][1]=1;
    for(k=2;k<(n*n)/2+1;k++)
    {
        if(dir==1)
        {
            i--;
            j++;
            if(i<1)
            {
                i=1;
                dir=0;
            }
            a[i][j]=k;
            continue;
        }
        if(dir==0)
        {
            i++;
            j--;
            if(j<1)
            {
                j=1;
                dir=1;
            }
            a[i][j]=k;
            continue;
        }
    }
    for(k=(n*n)/2+1;k<=n*n;k++)
    {
        if(dir==1)
        {
            i--;
            j++;
            if(j>n)
            {
                j=n;
                i=i+2;
                dir=0;
            }
            a[i][j]=k;
            continue;
        }
        if(dir==0)
        {
            i++;
            j--;
            if(i>n)
            {
                j=j+2;
                i=n;
                dir=1;
            }
            a[i][j]=k;
            continue;
        }
    }
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
            cout<<a[i][j]<<" ";
        cout<<endl;
    }
    return 0;
}
