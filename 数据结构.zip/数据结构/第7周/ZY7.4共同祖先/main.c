#include <stdio.h>
#include <stdlib.h>

typedef struct tnode
{
    char data;
    struct tnode *lchild;
    struct tnode *rchild;
}tnode,*tree;

typedef struct
{
    tree arr[50];
    int top;
}stack;

void push(stack *s,tree t)
{
    s->arr[++s->top]=t;
}

tree pop(stack *s)
{
    tree n=s->arr[s->top--];
    return n;
}

char gettop(stack *s)
{
    char n=s->arr[s->top]->data;
    return n;
}

int findpos(char ch,char s[])
{
    int i=0;
    for(i=0;s[i]!='\0';i++)
    {
        if(s[i]==ch)
            return i;
    }
    return 0;
}

void generate(tree *root,char s1[],char s2[])
{
    *root=(tnode*)malloc(sizeof(tnode));
    (*root)->lchild=(*root)->rchild=NULL;
    (*root)->data=s1[0];
    tree temp=*root;
    tree newroot;
    int i=0,j=0,rootpos;//in s2
    stack s;
    s.top=-1;
    push(&s,temp);
    rootpos=findpos(s1[0],s2);

    while(s1[i]!='\0')
    {
        i++;
        if(findpos(s1[i],s2)<rootpos)
        {
            newroot=(tnode*)malloc(sizeof(tnode));
            newroot->lchild=newroot->rchild=NULL;
            temp->lchild=newroot;
            newroot->data=s1[i];
            temp=newroot;
            rootpos=findpos(s1[i],s2);
            push(&s,temp);
        }
        else
        {
            temp=pop(&s);
            rootpos=findpos(s1[i],s2);
            if(findpos(gettop(&s),s2)>rootpos)
            {
                newroot=(tnode*)malloc(sizeof(tnode));
                newroot->lchild=newroot->rchild=NULL;
                temp->rchild=newroot;
                newroot->data=s1[i];
                temp=newroot;
                push(&s,temp);
            }
            else
            {
                temp=pop(&s);
                newroot=(tnode*)malloc(sizeof(tnode));
                newroot->lchild=newroot->rchild=NULL;
                temp->rchild=newroot;
                newroot->data=s1[i];
                temp=newroot;
                push(&s,temp);
            }
        }
    }
}

tree findancestor(tree t,tree a,tree b)
{
    if(t==a||t==b||t==NULL)
        return t;

    tree left=findancestor(t->lchild,a,b);
    tree right=findancestor(t->rchild,a,b);


    if(!left&&!right)
        return NULL;
    else if(left&&!right)
        return left;
    else if(!left&&right)
        return right;
    return t;
}

void init(stack *s)
{
    s->top=-1;
}

tree fansile(tree root,char ch)
{
    stack s;
    init(&s);
    tnode *p;
    p=root;
    while(p||(s.top!=-1))
    {
        if(p)
        {
            if(p->data==ch)
                return p;
            push(&s,p);
            p=p->lchild;
        }
        else
        {
            p=pop(&s);
            p=p->rchild;
        }
    }
}

int main()
{
    char pre[50],mid[50];
    char n1,n2;
    gets(pre);
    gets(mid);
    tree t,r,p,q;
    scanf("%c%c",&n1,&n2);
    generate(&t,pre,mid);
    //fansile(t);
    p=fansile(t,n1);
    q=fansile(t,n2);
    r=findancestor(t,p,q);
    if(r->data==n1||r->data==n2)
        printf("NULL");
    else
        printf("%c",r->data);
    return 0;
}
