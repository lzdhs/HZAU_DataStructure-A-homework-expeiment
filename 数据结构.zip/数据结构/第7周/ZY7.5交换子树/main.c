#include <stdio.h>
#include <stdlib.h>

int count=0;
typedef struct tnode
{
    char data;
    struct tnode *lchild;
    struct tnode *rchild;
}tnode,*tree;

void createtree(tree *bt)
{
    char ch;
    ch=getchar();
    if(ch=='#')
        *bt=NULL;
    else
    {
        *bt=(tree)malloc(sizeof(tnode));
        (*bt)->data=ch;
        createtree(&((*bt)->lchild));
        createtree(&((*bt)->rchild));
    }
}

void postorder(tree root)//digui
{
    if(root!=NULL)
    {
        postorder(root->lchild);
        postorder(root->rchild);
        printf("%c",root->data);
    }
    else
        printf("#");
}

void exchange(tree *t)
{
    tree temp;
    temp=(*t)->rchild;
    (*t)->rchild=(*t)->lchild;
    (*t)->lchild=temp;
    if((*t)->lchild==NULL&&(*t)->rchild==NULL)
    {
        count++;
        return;
    }
    if((*t)->lchild!=NULL)
        exchange(&(*t)->lchild);
    if((*t)->rchild!=NULL)
        exchange(&(*t)->rchild);
}
int main()
{
    tree t;
    createtree(&t);
    exchange(&t);
    printf("%d\n",count);
    postorder(t);
    return 0;
}
