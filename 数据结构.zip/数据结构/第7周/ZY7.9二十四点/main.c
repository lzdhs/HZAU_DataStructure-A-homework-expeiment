#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int num[4];
    int top;
}numstack;

typedef struct
{
    char oper[4];
    int top;
}opstack;

void initnum(numstack *a)
{
    a->top=-1;
}

void pushnum(numstack *a,int data)
{
    a->top++;
    a->num[a->top]=data;
}

int popnum(numstack *a)
{
    int i=a->num[a->top];
    a->top--;
    return i;
}

void initop(opstack *a)
{
    a->top=-1;
}

void pushop(opstack *a,char data)
{
    a->top++;
    a->oper[a->top]=data;
}

char popop(opstack *a)
{
    char i=a->oper[a->top];
    a->top--;
    return i;
}

char gettop(opstack a)
{
    char i=a.oper[a.top];
    return i;
}

int compare(char s1,char s2)
{
    if(s1=='x'||s1=='/')
        return 1;
    else if((s1=='+'&&s2=='+')||(s1=='+'&&s2=='-')||(s1=='-'&&s2=='+')||(s1=='-'&&s2=='-'))
        return 0;
}

int main()
{
    numstack num;
    opstack op;
    char s[10],ch;
    gets(s);
    int i,temp;
    //pushop(&op,'#');
    for(i=0;s[i]!='\0';i++)
    {
        if(s[i]>='0'&&s[i]<='9')
            pushnum(&num,s[i]-'0');
        else
        {
            if(compare(s[i],gettop(op)))
            {
                if(s[i]=='x')
                {
                    temp=popnum(&op)*(s[i+1]-'0');
                    pushnum(&num,temp);
                    i++;
                }
            }
            else
            {
                pushop(&op,s[i]);
            }
        }
    }
    while(op.top!=-1)
    {
        temp=popnum(&num);
        ch=popop(&op);
        if(ch=='+')
        {
            temp=temp+popnum(&num);
            pushnum(&num,temp);
        }
        else
        {
            temp=-temp+popnum(&num);
            pushnum(&num,temp);
        }
    }
    if(popnum(&num)==24)
        printf("yes");
    else
        printf("no");
    return 0;
}
